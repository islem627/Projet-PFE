package com.example.firebase24;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Firebase24ApplicationTests {

	@Test
	void contextLoads() {
	}

}
