package com.example.websocket.Controller;

public enum WsChatMessageType {
    JOIN,
    LEAVE,
    CHAT

}