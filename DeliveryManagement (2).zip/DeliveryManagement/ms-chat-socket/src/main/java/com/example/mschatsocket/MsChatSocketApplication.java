package com.example.mschatsocket;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsChatSocketApplication {

    public static void main(String[] args) {
        SpringApplication.run(MsChatSocketApplication.class, args);
    }

}
