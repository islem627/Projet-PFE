package com.example.pusherh;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PusherHApplication {

    public static void main(String[] args) {
        SpringApplication.run(PusherHApplication.class, args);
    }

}
