package com.example.pusherh;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PusherHApplicationTests {

    @Test
    void contextLoads() {
    }

}
