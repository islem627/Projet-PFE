package com.example.pusherbeams;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PusherbeamsApplication {

    public static void main(String[] args) {
        SpringApplication.run(PusherbeamsApplication.class, args);
    }

}
