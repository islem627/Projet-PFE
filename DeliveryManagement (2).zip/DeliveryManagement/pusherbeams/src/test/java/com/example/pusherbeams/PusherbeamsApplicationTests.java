package com.example.pusherbeams;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PusherbeamsApplicationTests {

    @Test
    void contextLoads() {
    }

}
