package com.example.deliverymanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DeliveryManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(DeliveryManagementApplication.class, args);
	}

}
