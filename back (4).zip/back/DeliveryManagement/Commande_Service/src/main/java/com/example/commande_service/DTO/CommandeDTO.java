package com.example.commande_service.DTO;

import com.example.commande_service.entities.CommandeEntity;

import java.time.LocalDate;
import java.time.LocalDateTime;


public class CommandeDTO {
    private Long id_commande;
    private LocalDate dateCommande;
    private String statut_commande;
    private String adresse_livraison;
    private double total;
    private String articel_commande;
    private double remise;
    private double fraisLivraison;
    private LocalDate date_livraison_estimee;
    private String commentaires;
    private boolean ispaied = false;
    private double latitude;
    private double longitude;
    private Long idproduit;
    private Long iduser;
    private ProductDTO productDTO;
    private UserDTO userDTO;
    private Long livreurId;
    private String gouvernoratCmd;

    // New fields
    private LocalDateTime date_ajoutsystem;
    private LocalDateTime date_affection;
    private LocalDateTime date_expidetion;
    private LocalDateTime date_livree;
    private String enseigne;
    private String destination_enseigne;
    private double poids_grammes;
    private double hauteur_cm;
    private double largeur_cm;
    private double longueur_cm;
    private boolean archived;
    private String commentaireClient;
    private Float noteClient;
    private  Long idpartenaire;
    private String fixe_temps;

    public String getFixe_temps() {
        return fixe_temps;
    }

    public void setFixe_temps(String fixe_temps) {
        this.fixe_temps = fixe_temps;
    }

    public boolean isIspaied() {
        return ispaied;
    }

    public Long getIdpartenaire() {
        return idpartenaire;
    }

    public void setIdpartenaire(Long idpartenaire) {
        this.idpartenaire = idpartenaire;
    }

    public boolean isArchived() {
        return archived;
    }

    public void setArchived(boolean archived) {
        this.archived = archived;
    }

    public String getCommentaireClient() {
        return commentaireClient;
    }

    public void setCommentaireClient(String commentaireClient) {
        this.commentaireClient = commentaireClient;
    }

    public Float getNoteClient() {
        return noteClient;
    }

    public void setNoteClient(Float noteClient) {
        this.noteClient = noteClient;
    }

    public Long getId_commande() {
        return id_commande;
    }

    public void setId_commande(Long id_commande) {
        this.id_commande = id_commande;
    }

    public LocalDate getDateCommande() {
        return dateCommande;
    }

    public void setDateCommande(LocalDate dateCommande) {
        this.dateCommande = dateCommande;
    }

    public String getStatut_commande() {
        return statut_commande;
    }

    public void setStatut_commande(String statut_commande) {
        this.statut_commande = statut_commande;
    }

    public String getAdresse_livraison() {
        return adresse_livraison;
    }

    public void setAdresse_livraison(String adresse_livraison) {
        this.adresse_livraison = adresse_livraison;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    public String getArticel_commande() {
        return articel_commande;
    }

    public void setArticel_commande(String articel_commande) {
        this.articel_commande = articel_commande;
    }

    public double getRemise() {
        return remise;
    }

    public void setRemise(double remise) {
        this.remise = remise;
    }

    public double getFraisLivraison() {
        return fraisLivraison;
    }

    public void setFraisLivraison(double fraisLivraison) {
        this.fraisLivraison = fraisLivraison;
    }

    public LocalDate getDate_livraison_estimee() {
        return date_livraison_estimee;
    }

    public void setDate_livraison_estimee(LocalDate date_livraison_estimee) {
        this.date_livraison_estimee = date_livraison_estimee;
    }

    public String getCommentaires() {
        return commentaires;
    }

    public void setCommentaires(String commentaires) {
        this.commentaires = commentaires;
    }

    public boolean getIspaied() {
        return ispaied;
    }

    public void setIspaied(boolean ispaied) {
        this.ispaied = ispaied;
    }

    public double getLatitude() {
        return latitude;
    }

    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }

    public Long getIdproduit() {
        return idproduit;
    }

    public void setIdproduit(Long idproduit) {
        this.idproduit = idproduit;
    }

    public Long getIduser() {
        return iduser;
    }

    public void setIduser(Long iduser) {
        this.iduser = iduser;
    }

    public ProductDTO getProductDTO() {
        return productDTO;
    }

    public void setProductDTO(ProductDTO productDTO) {
        this.productDTO = productDTO;
    }

    public UserDTO getUserDTO() {
        return userDTO;
    }

    public void setUserDTO(UserDTO userDTO) {
        this.userDTO = userDTO;
    }

    public Long getLivreurId() {
        return livreurId;
    }

    public void setLivreurId(Long livreurId) {
        this.livreurId = livreurId;
    }

    public String getGouvernoratCmd() {
        return gouvernoratCmd;
    }

    public void setGouvernoratCmd(String gouvernoratCmd) {
        this.gouvernoratCmd = gouvernoratCmd;
    }

    public LocalDateTime getDate_ajoutsystem() {
        return date_ajoutsystem;
    }

    public void setDate_ajoutsystem(LocalDateTime date_ajoutsystem) {
        this.date_ajoutsystem = date_ajoutsystem;
    }

    public LocalDateTime getDate_affection() {
        return date_affection;
    }

    public void setDate_affection(LocalDateTime date_affection) {
        this.date_affection = date_affection;
    }

    public LocalDateTime getDate_expidetion() {
        return date_expidetion;
    }

    public void setDate_expidetion(LocalDateTime date_expidetion) {
        this.date_expidetion = date_expidetion;
    }

    public LocalDateTime getDate_livree() {
        return date_livree;
    }

    public void setDate_livree(LocalDateTime date_livree) {
        this.date_livree = date_livree;
    }

    public String getEnseigne() {
        return enseigne;
    }

    public void setEnseigne(String enseigne) {
        this.enseigne = enseigne;
    }

    public String getDestination_enseigne() {
        return destination_enseigne;
    }

    public void setDestination_enseigne(String destination_enseigne) {
        this.destination_enseigne = destination_enseigne;
    }

    public double getPoids_grammes() {
        return poids_grammes;
    }

    public void setPoids_grammes(double poids_grammes) {
        this.poids_grammes = poids_grammes;
    }

    public double getHauteur_cm() {
        return hauteur_cm;
    }

    public void setHauteur_cm(double hauteur_cm) {
        this.hauteur_cm = hauteur_cm;
    }

    public double getLargeur_cm() {
        return largeur_cm;
    }

    public void setLargeur_cm(double largeur_cm) {
        this.largeur_cm = largeur_cm;
    }

    public double getLongueur_cm() {
        return longueur_cm;
    }

    public void setLongueur_cm(double longueur_cm) {
        this.longueur_cm = longueur_cm;
    }

    public CommandeDTO(Long id_commande, LocalDate dateCommande, String statut_commande, String adresse_livraison, double total, String articel_commande, double remise, double fraisLivraison, LocalDate date_livraison_estimee, String commentaires, boolean ispaied, double latitude, double longitude, Long idproduit, Long iduser, ProductDTO productDTO, UserDTO userDTO, Long livreurId, String gouvernoratCmd, LocalDateTime date_ajoutsystem, LocalDateTime date_affection, LocalDateTime date_expidetion, LocalDateTime date_livree, String enseigne, String destination_enseigne, double poids_grammes, double hauteur_cm, double largeur_cm, double longueur_cm, boolean archived, String commentaireClient, Float noteClient, Long idpartenaire, String fixe_temps) {
        this.id_commande = id_commande;
        this.dateCommande = dateCommande;
        this.statut_commande = statut_commande;
        this.adresse_livraison = adresse_livraison;
        this.total = total;
        this.articel_commande = articel_commande;
        this.remise = remise;
        this.fraisLivraison = fraisLivraison;
        this.date_livraison_estimee = date_livraison_estimee;
        this.commentaires = commentaires;
        this.ispaied = ispaied;
        this.latitude = latitude;
        this.longitude = longitude;
        this.idproduit = idproduit;
        this.iduser = iduser;
        this.productDTO = productDTO;
        this.userDTO = userDTO;
        this.livreurId = livreurId;
        this.gouvernoratCmd = gouvernoratCmd;
        this.date_ajoutsystem = date_ajoutsystem;
        this.date_affection = date_affection;
        this.date_expidetion = date_expidetion;
        this.date_livree = date_livree;
        this.enseigne = enseigne;
        this.destination_enseigne = destination_enseigne;
        this.poids_grammes = poids_grammes;
        this.hauteur_cm = hauteur_cm;
        this.largeur_cm = largeur_cm;
        this.longueur_cm = longueur_cm;
        this.archived = archived;
        this.commentaireClient = commentaireClient;
        this.noteClient = noteClient;
        this.idpartenaire = idpartenaire;
        this.fixe_temps = fixe_temps;
    }

    public CommandeDTO() {
    }

    public CommandeEntity toEntity(CommandeDTO commandeDTO) {
        CommandeEntity commandeEntity = new CommandeEntity();

        commandeEntity.setId_commande(commandeDTO.getId_commande());
        commandeEntity.setDateCommande(commandeDTO.getDateCommande());
        commandeEntity.setStatut_commande(commandeDTO.getStatut_commande());
        commandeEntity.setAdresse_livraison(commandeDTO.getAdresse_livraison());
        commandeEntity.setTotal(commandeDTO.getTotal());
        commandeEntity.setArticel_commande(commandeDTO.getArticel_commande());
        commandeEntity.setRemise(commandeDTO.getRemise());
        commandeEntity.setFraisLivraison(commandeDTO.getFraisLivraison());
        commandeEntity.setDate_livraison_estimee(commandeDTO.getDate_livraison_estimee());
        commandeEntity.setCommentaires(commandeDTO.getCommentaires());
        commandeEntity.setIspaied(commandeDTO.getIspaied());
        commandeEntity.setLatitude(commandeDTO.getLatitude());
        commandeEntity.setLongitude(commandeDTO.getLongitude());
        commandeEntity.setIdproduit(commandeDTO.getIdproduit());
        commandeEntity.setIduser(commandeDTO.getIduser());
        commandeEntity.setLivreurId(commandeDTO.getLivreurId());
        commandeEntity.setGouvernoratCmd(commandeDTO.getGouvernoratCmd());
        commandeEntity.setProductDTO(commandeDTO.getProductDTO());
        commandeEntity.setUserDTO(commandeDTO.getUserDTO());
        commandeEntity.setDate_ajoutsystem(commandeDTO.getDate_ajoutsystem());
        commandeEntity.setDate_affection(commandeDTO.getDate_affection());
        commandeEntity.setDate_expidetion(commandeDTO.getDate_expidetion());
        commandeEntity.setDate_livree(commandeDTO.getDate_livree());
        commandeEntity.setEnseigne(commandeDTO.getEnseigne());
        commandeEntity.setDestination_enseigne(commandeDTO.getDestination_enseigne());
        commandeEntity.setPoids_grammes(commandeDTO.getPoids_grammes());
        commandeEntity.setHauteur_cm(commandeDTO.getHauteur_cm());
        commandeEntity.setLargeur_cm(commandeDTO.getLargeur_cm());
        commandeEntity.setLongueur_cm(commandeDTO.getLongueur_cm());
        commandeEntity.setArchived(commandeDTO.isArchived());
        commandeEntity.setNoteClient(commandeDTO.getNoteClient());
        commandeEntity.setCommentaireClient(commandeDTO.getCommentaireClient());
        commandeEntity.setIdpartenaire(commandeDTO.getIdpartenaire());
        commandeEntity.setFixe_temps(commandeDTO.getFixe_temps());
        return commandeEntity;
    }


    public CommandeDTO fromEntity(CommandeEntity commandeEntity) {
        {
            CommandeDTO commandeDTO = new CommandeDTO();//création d'une nouvelle instancethis.id_commande = commandeEntity.getId_commande();


            commandeDTO.setId_commande(commandeEntity.getId_commande());
            commandeDTO.setDateCommande(commandeEntity.getDateCommande());
            commandeDTO.setStatut_commande(commandeEntity.getStatut_commande());
            commandeDTO.setAdresse_livraison(commandeEntity.getAdresse_livraison());
            commandeDTO.setTotal(commandeEntity.getTotal());
            commandeDTO.setArticel_commande(commandeEntity.getArticel_commande());
            commandeDTO.setRemise(commandeEntity.getRemise());
            commandeDTO.setFraisLivraison(commandeEntity.getFraisLivraison());
            commandeDTO.setDate_livraison_estimee(commandeEntity.getDate_livraison_estimee());
            commandeDTO.setCommentaires(commandeEntity.getCommentaires());
            commandeDTO.setIspaied(commandeEntity.getIspaied());
            commandeDTO.setLatitude(commandeEntity.getLatitude());
            commandeDTO.setLongitude(commandeEntity.getLongitude());
            commandeDTO.setIdproduit(commandeEntity.getIdproduit());
            commandeDTO.setIduser(commandeEntity.getIduser());
            commandeDTO.setLivreurId(commandeEntity.getLivreurId());
            commandeDTO.setGouvernoratCmd(commandeEntity.getGouvernoratCmd());
            commandeDTO.setProductDTO(commandeEntity.getProductDTO());
            commandeDTO.setUserDTO(commandeEntity.getUserDTO());
            commandeDTO.setDate_ajoutsystem(commandeEntity.getDate_ajoutsystem());
            commandeDTO.setDate_affection(commandeEntity.getDate_affection());
            commandeDTO.setDate_expidetion(commandeEntity.getDate_expidetion());
            commandeDTO.setDate_livree(commandeEntity.getDate_livree());
            commandeDTO.setEnseigne(commandeEntity.getEnseigne());
            commandeDTO.setDestination_enseigne(commandeEntity.getDestination_enseigne());
            commandeDTO.setPoids_grammes(commandeEntity.getPoids_grammes());
            commandeDTO.setHauteur_cm(commandeEntity.getHauteur_cm());
            commandeDTO.setLargeur_cm(commandeEntity.getLargeur_cm());
            commandeDTO.setLongueur_cm(commandeEntity.getLongueur_cm());
            commandeDTO.setNoteClient(commandeEntity.getNoteClient());
            commandeDTO.setCommentaireClient(commandeEntity.getCommentaireClient());
            commandeDTO.setArchived(commandeEntity.isArchived());
            commandeDTO.setIdpartenaire(commandeEntity.getIdpartenaire());
            commandeDTO.setFixe_temps(commandeEntity.getFixe_temps());


            return commandeDTO;

        }


    }
}

