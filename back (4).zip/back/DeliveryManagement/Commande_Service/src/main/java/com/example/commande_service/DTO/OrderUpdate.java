package com.example.commande_service.DTO;

public class OrderUpdate {
    private String orderId;
    private String status;
    private Long iduser;
    private Long idpartenaire;
    private String articelCommande;
    private String adresseLivraison;
    private String dateCommande;

    // Getters and Setters
    public String getOrderId() { return orderId; }
    public void setOrderId(String orderId) { this.orderId = orderId; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public Long getIduser() { return iduser; }
    public void setIduser(Long iduser) { this.iduser = iduser; }
    public Long getIdpartenaire() { return idpartenaire; }
    public void setIdpartenaire(Long idpartenaire) { this.idpartenaire = idpartenaire; }
    public String getArticelCommande() { return articelCommande; }
    public void setArticelCommande(String articelCommande) { this.articelCommande = articelCommande; }
    public String getAdresseLivraison() { return adresseLivraison; }
    public void setAdresseLivraison(String adresseLivraison) { this.adresseLivraison = adresseLivraison; }
    public String getDateCommande() { return dateCommande; }
    public void setDateCommande(String dateCommande) { this.dateCommande = dateCommande; }
}