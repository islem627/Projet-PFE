package com.example.commande_service.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.http.server.ServerHttpRequest;
import org.springframework.http.server.ServletServerHttpRequest;
import org.springframework.messaging.simp.config.MessageBrokerRegistry;
import org.springframework.web.socket.WebSocketHandler;
import org.springframework.web.socket.config.annotation.EnableWebSocketMessageBroker;
import org.springframework.web.socket.config.annotation.StompEndpointRegistry;
import org.springframework.web.socket.config.annotation.WebSocketMessageBrokerConfigurer;
import org.springframework.web.socket.server.support.DefaultHandshakeHandler;

import java.security.Principal;
import java.util.Map;

@Configuration
@EnableWebSocketMessageBroker
public class WebSocketConfig implements WebSocketMessageBrokerConfigurer {


//    @Override
//    public void configureMessageBroker(MessageBrokerRegistry config) {
//        config.enableSimpleBroker("/topic", "/queue");
//        config.setApplicationDestinationPrefixes("/app");
//        config.setUserDestinationPrefix("/user");
//    }
//
//
//
//
//
//    @Override
//    public void registerStompEndpoints(StompEndpointRegistry registry) {
//        registry.addEndpoint("/ws")
//                .setHandshakeHandler(new DefaultHandshakeHandler() {
//                    @Override
//                    protected Principal determineUser(ServerHttpRequest request, WebSocketHandler wsHandler, Map<String, Object> attributes) {
//                        if (request instanceof ServletServerHttpRequest servletRequest) {
//                            var servlet = servletRequest.getServletRequest();
//                            String userId = servlet.getParameter("userId");
//
//                            if (userId != null && !userId.isEmpty()) {
//                                System.out.println("✅ Assigning WebSocket principal as userId: " + userId);
//                                return () -> userId;
//                            }
//                        }
//                        System.out.println("❌ No userId provided in WebSocket URL");
//                        return () -> "anonymous"; // fallback
//                    }
//                })
//                .setAllowedOriginPatterns("*")
//                .withSockJS();
//    }





        @Override
    public void configureMessageBroker(MessageBrokerRegistry config) {
        config.enableSimpleBroker("/topic"); // broker en mémoire simple
        config.setApplicationDestinationPrefixes("/app"); // préfixe pour les messages entrants
    }

        @Override
    public void registerStompEndpoints(StompEndpointRegistry registry) {
        registry.addEndpoint("/ws") // chemin WebSocket
               .setAllowedOrigins("http://localhost:4200")
               // .setAllowedOrigins("*")
                .withSockJS();
    }

}