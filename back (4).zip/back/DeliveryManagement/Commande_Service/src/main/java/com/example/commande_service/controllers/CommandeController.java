package com.example.commande_service.controllers;

import com.example.commande_service.DTO.CommandeDTO;
import com.example.commande_service.DTO.OrderUpdate;
import com.example.commande_service.DTO.ProductDTO;
import com.example.commande_service.DTO.UserDTO;
import com.example.commande_service.entities.CommandeEntity;
import com.example.commande_service.openfile.Client_produit;
import com.example.commande_service.openfile.Commande_user;
import com.example.commande_service.repositories.CommandeRepo;
import com.example.commande_service.services.CommandeService;
import com.example.commande_service.services.NotificationService;
import feign.FeignException;
import jakarta.validation.ConstraintViolationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.*;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.server.ResponseStatusException;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/Commande")
@CrossOrigin(origins = "http://localhost:4200")


public class CommandeController {
    private static final Logger logger = LoggerFactory.getLogger(CommandeController.class);

    @Autowired
    CommandeService commandeService;

    @Autowired
    Client_produit client_product;
    @Autowired
    Commande_user commande_user;
    @Autowired
    private CommandeRepo commandeRepo;
    @Autowired
    private NotificationService notificationService;
    @Autowired
    private RestTemplate restTemplate;

    @Value("${realtime24.notify.url:http://localhost:8080/notify/order-update}")
    private String notifyUrl;



    @DeleteMapping("/delete/{id_commande}")
    public void delete(@PathVariable Long id_commande) {
        commandeService.Delete(id_commande);
    }

    // ✅ Créer une nouvelle commande
    @PostMapping("/create/{idproduit}")
    public CommandeDTO addCommande(CommandeEntity commandeEntity, @PathVariable Long idproduit) {


        ProductDTO productDTO = client_product.getProduct(idproduit);


        CommandeEntity x = commandeService.create(commandeEntity);
        x.setIdproduit(idproduit);
        x.setProductDTO(productDTO);


        CommandeDTO commandeDTO = new CommandeDTO().fromEntity(x);
        commandeDTO.setIdproduit(idproduit);
        commandeDTO.setProductDTO(productDTO);
        commandeDTO.setLivreurId(commandeDTO.getLivreurId());
        return commandeDTO;
    }


    @PostMapping("/createE")
    public CommandeDTO addCommandeE(CommandeEntity commandeEntity) {
        CommandeEntity x = commandeService.create(commandeEntity);
        CommandeDTO commandeDTO = new CommandeDTO().fromEntity(x);
        return commandeDTO;
    }


  /* @GetMapping("/getcmd/{id_commande}")
    public CommandeDTO getCommande(@PathVariable Long id_commande) {
        // Récupération de la commande depuis le service
        CommandeEntity c = commandeService.one_commande(id_commande);

        // Transformation de l'entité en DTO
        CommandeDTO commandeDTO = new CommandeDTO().fromEntity(c);

        // Ajout des informations iduser et idproduit
        commandeDTO.setIduser(c.getIduser());
        commandeDTO.setIdproduit(c.getIdproduit());
        commandeDTO.setLivreurId(c.getLivreurId());

        // Si les IDs utilisateur et produit ne sont pas null, récupération des DTOs associés
        if (c.getIduser() != null && c.getIdproduit() != null) {
            try {
                UserDTO userDTO = commande_user.getUser(c.getIduser());
                ProductDTO productDTO = client_product.getProduct(c.getIdproduit());

                commandeDTO.setUserDTO(userDTO);
                commandeDTO.setProductDTO(productDTO);
            } catch (FeignException.NotFound e) {
                // En cas d'exception, on affiche un message d'erreur
                System.err.println("Produit ou utilisateur non trouvé pour la commande ID: " + c.getId_commande());
            }
        }

        // Retour du DTO final
        return commandeDTO;
    }
*/



    @PutMapping("/updateCMD/{id_commande}")
    public CommandeDTO update(@PathVariable Long id_commande, CommandeEntity commandeEntity) {


        commandeEntity.setId_commande(id_commande);
        //avoir instance old commande
        CommandeEntity old_commande = commandeService.one_commande(id_commande);

        if (commandeEntity.getId_commande() == null) {
            commandeEntity.setId_commande(old_commande.getId_commande());
        }
        if (commandeEntity.getStatut_commande() == null) {
            commandeEntity.setStatut_commande(old_commande.getStatut_commande());
        }
        if (commandeEntity.getArticel_commande() == null) {
            commandeEntity.setArticel_commande(old_commande.getArticel_commande());
        }
        if (commandeEntity.getDateCommande() == null) {
            commandeEntity.setDateCommande(old_commande.getDateCommande());
        }
        if (commandeEntity.getCommentaires() == null) {
            commandeEntity.setCommentaires(old_commande.getCommentaires());
        }
        if (commandeEntity.getAdresse_livraison() == null) {
            commandeEntity.setAdresse_livraison(old_commande.getAdresse_livraison());
        }
        if (commandeEntity.getDate_livraison_estimee() == null) {
            commandeEntity.setDate_livraison_estimee(old_commande.getDate_livraison_estimee());
        }
        if (commandeEntity.getFraisLivraison() == 0) {
            commandeEntity.setFraisLivraison(old_commande.getFraisLivraison());
        }
        if (commandeEntity.getRemise() == 0) {
            commandeEntity.setRemise(old_commande.getRemise());
        }
        if (commandeEntity.getTotal() == 0) {
            commandeEntity.setTotal(old_commande.getTotal());
        }
        if (commandeEntity.getDate_livraison_estimee() == null) {
            commandeEntity.setDate_livraison_estimee(old_commande.getDate_livraison_estimee());
        }
        if (commandeEntity.getLatitude() == 0) {
            commandeEntity.setLatitude(old_commande.getLatitude());
        }
        if (commandeEntity.getLongitude() == 0) {
            commandeEntity.setLongitude(old_commande.getLongitude());
        }
        if (commandeEntity.getLivreurId() == null || commandeEntity.getLivreurId() == 0) {
            commandeEntity.setLivreurId(old_commande.getLivreurId());
        }

        if (commandeEntity.getEnseigne() == null) {
            commandeEntity.setEnseigne(old_commande.getEnseigne());
        }
        if (commandeEntity.getDate_ajoutsystem() == null) {
            commandeEntity.setDate_ajoutsystem(old_commande.getDate_ajoutsystem());
        }
        if (commandeEntity.getDate_affection() == null) {
            commandeEntity.setDate_affection(old_commande.getDate_affection());
        }
        if (commandeEntity.getDate_expidetion() == null) {
            commandeEntity.setDate_expidetion(old_commande.getDate_expidetion());
        }
        if (commandeEntity.getDate_livree() == null) {
            commandeEntity.setDate_livree(old_commande.getDate_livree());
        }
        if (commandeEntity.getEnseigne() == null) {
            commandeEntity.setEnseigne(old_commande.getEnseigne());
        }
        if (commandeEntity.getDestination_enseigne() == null) {
            commandeEntity.setDestination_enseigne(old_commande.getDestination_enseigne());
        }
        if (commandeEntity.getPoids_grammes() == 0.0) {
            commandeEntity.setPoids_grammes(old_commande.getPoids_grammes());
        }
        if (commandeEntity.getHauteur_cm() == 0.0) {
            commandeEntity.setHauteur_cm(old_commande.getHauteur_cm());
        }
        if (commandeEntity.getLargeur_cm() == 0.0) {
            commandeEntity.setLargeur_cm(old_commande.getLargeur_cm());
        }
        if (commandeEntity.getLongueur_cm() == 0.0) {
            commandeEntity.setLongueur_cm(old_commande.getLongueur_cm());
        }
        if (commandeEntity.getGouvernoratCmd() == null) {
            commandeEntity.setGouvernoratCmd(old_commande.getGouvernoratCmd());
        }
        if (commandeEntity.getIspaied() == false) {
            commandeEntity.setIspaied(old_commande.getIspaied());
        }
        if(commandeEntity.getFixe_temps() == null) {
            commandeEntity.setFixe_temps(old_commande.getFixe_temps());
        }
        CommandeEntity cmd = commandeService.update(commandeEntity);
        CommandeDTO cmdDTO = new CommandeDTO().fromEntity(cmd);
        return cmdDTO;
    }


   /* pour tester fraislivraion @PostMapping("/createUP/{iduser}/{idproduit}")
    public CommandeDTO addCommandeUser(
            @ModelAttribute CommandeEntity commandeEntity,
            @PathVariable Long iduser,
            @PathVariable Long idproduit,
            @RequestParam("date_ajoutsystem") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime dateAjoutsystem) {

        logger.info("Valeur reçue de date_ajoutsystem: {}", dateAjoutsystem);

        UserDTO userDTO = commande_user.getUser(iduser);
        ProductDTO productDTO = client_product.getProduct(idproduit);

        // Préparer l’objet complet
        commandeEntity.setIduser(iduser);
        commandeEntity.setUserDTO(userDTO);
        commandeEntity.setIdproduit(idproduit);
        commandeEntity.setProductDTO(productDTO);

        // Gestion de la date
        LocalDateTime adjustedDateAjoutSystem = dateAjoutsystem.plusHours(1);


        // Enregistrer dans la base
        CommandeEntity x = commandeService.create(commandeEntity);
        logger.info("Date enregistrée dans la base: {}", x.getDate_expidetion());

        // Préparer le DTO à retourner
        CommandeDTO commandeDTO = new CommandeDTO().fromEntity(x);
        commandeDTO.setIdproduit(idproduit);
        commandeDTO.setUserDTO(userDTO);
        commandeDTO.setProductDTO(productDTO);

        return commandeDTO;
    }*/
   @PostMapping("/createUP/{iduser}")
   public ResponseEntity<CommandeDTO> addCommandeUser(
           @ModelAttribute CommandeEntity commandeEntity,
           @PathVariable Long iduser,
           @RequestParam(value = "date_ajoutsystem", required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime dateAjoutsystem,
           @RequestParam(value = "deliveryOption", required = false) String deliveryOption) {

       logger.info("Valeur reçue de date_ajoutsystem: {}", dateAjoutsystem);
       logger.info("Option de livraison reçue: {}", deliveryOption);

       // Validation des paramètres
       if (commandeEntity.getPoids_grammes() <= 0) {
           logger.error("Le poids doit être supérieur à 0.");
           return ResponseEntity.badRequest().body(null);
       }
       if (commandeEntity.getIdpartenaire() == null) {
           logger.error("L'ID du partenaire doit être fourni.");
           return ResponseEntity.badRequest().body(null);
       }
       if (commandeEntity.getAdresse_livraison() == null || commandeEntity.getAdresse_livraison().isEmpty()) {
           logger.error("L'adresse de livraison doit être fournie.");
           return ResponseEntity.badRequest().body(null);
       }
       if (commandeEntity.getArticel_commande() == null || commandeEntity.getArticel_commande().isEmpty()) {
           logger.error("L'article de la commande doit être fourni.");
           return ResponseEntity.badRequest().body(null);
       }
       if (commandeEntity.getTotal() <= 0) {
           logger.error("Le total doit être supérieur à 0.");
           return ResponseEntity.badRequest().body(null);
       }

       // Récupérer les DTOs
       UserDTO userDTO = commande_user.getUser(iduser);


       // Préparer l’objet complet
       commandeEntity.setIduser(iduser);
       commandeEntity.setUserDTO(userDTO);
       if (dateAjoutsystem != null) {
           commandeEntity.setDate_ajoutsystem(dateAjoutsystem.plusHours(1));
       }

       // Enregistrer dans la base via le service
       CommandeEntity savedCommande = commandeService.createC(commandeEntity, deliveryOption);
       logger.info("Commande enregistrée avec frais de livraison: {}", savedCommande.getFraisLivraison());

       // Préparer le DTO à retourner
       CommandeDTO commandeDTO = new CommandeDTO().fromEntity(savedCommande);
       commandeDTO.setUserDTO(userDTO);

       return ResponseEntity.ok(commandeDTO);
   }

    @GetMapping("/calculate-fees")
    public ResponseEntity<Double> calculateDeliveryFees(
            @RequestParam double poids_grammes,
            @RequestParam String deliveryOption) {
        try {
            double frais = commandeService.calculerFraisLivraison(poids_grammes, deliveryOption);
            return ResponseEntity.ok(frais);
        } catch (IllegalArgumentException e) {
            logger.error("Erreur lors du calcul des frais: {}", e.getMessage());
            return ResponseEntity.badRequest().body(null);
        }
    }

    // Gestion des erreurs de validation
    @ExceptionHandler({ConstraintViolationException.class, MethodArgumentNotValidException.class})
    public ResponseEntity<Map<String, String>> handleValidationExceptions(Exception ex) {
        Map<String, String> errors = new HashMap<>();
        if (ex instanceof ConstraintViolationException) {
            ((ConstraintViolationException) ex).getConstraintViolations().forEach(violation ->
                    errors.put(violation.getPropertyPath().toString(), violation.getMessage()));
        } else if (ex instanceof MethodArgumentNotValidException) {
            ((MethodArgumentNotValidException) ex).getBindingResult().getFieldErrors().forEach(error ->
                    errors.put(error.getField(), error.getDefaultMessage()));
        }
        return new ResponseEntity<>(errors, HttpStatus.BAD_REQUEST);
    }

    // Gestion des erreurs génériques
    @ExceptionHandler(IllegalArgumentException.class)
    public ResponseEntity<Map<String, String>> handleIllegalArgumentException(IllegalArgumentException ex) {
        Map<String, String> error = new HashMap<>();
        error.put("error", ex.getMessage());
        return new ResponseEntity<>(error, HttpStatus.BAD_REQUEST);
    }
  /* @PutMapping("/updatecmd/{id_commande}")
    public CommandeDTO update(
            @PathVariable Long id_commande,
            @RequestParam(required = false) String statut_commande,
            @RequestParam(required = false) String date_expidetion,
            @RequestParam(required = false) String date_livree
    ) {
        logger.info("Requête PUT reçue pour updatecmd/{} avec statut_commande: {}, date_expidetion: {}, date_livree: {}",
                id_commande, statut_commande, date_expidetion, date_livree);

        // Récupérer l'ancienne commande
        CommandeEntity old_commande = commandeService.one_commande(id_commande);
        if (old_commande == null) {
            logger.error("Commande introuvable pour l'ID: {}", id_commande);
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Commande introuvable pour l'ID: " + id_commande);

        }

        // Créer une nouvelle instance de CommandeEntity avec les anciennes valeurs
        CommandeEntity commandeEntity = new CommandeEntity();
        commandeEntity.setId_commande(id_commande);
        commandeEntity.setStatut_commande(old_commande.getStatut_commande());
        commandeEntity.setArticel_commande(old_commande.getArticel_commande());
        commandeEntity.setDateCommande(old_commande.getDateCommande());
        commandeEntity.setCommentaires(old_commande.getCommentaires());
        commandeEntity.setAdresse_livraison(old_commande.getAdresse_livraison());
        commandeEntity.setDate_livraison_estimee(old_commande.getDate_livraison_estimee());
        commandeEntity.setFraisLivraison(old_commande.getFraisLivraison());
        commandeEntity.setRemise(old_commande.getRemise());
        commandeEntity.setTotal(old_commande.getTotal());
        commandeEntity.setLatitude(old_commande.getLatitude());
        commandeEntity.setLongitude(old_commande.getLongitude());
        commandeEntity.setLivreurId(old_commande.getLivreurId());
        commandeEntity.setEnseigne(old_commande.getEnseigne());
        commandeEntity.setDate_ajoutsystem(old_commande.getDate_ajoutsystem());
        commandeEntity.setDate_affection(old_commande.getDate_affection());
        commandeEntity.setDate_expidetion(old_commande.getDate_expidetion());
        commandeEntity.setDate_livree(old_commande.getDate_livree());
        commandeEntity.setDestination_enseigne(old_commande.getDestination_enseigne());
        commandeEntity.setPoids_grammes(old_commande.getPoids_grammes());
        commandeEntity.setHauteur_cm(old_commande.getHauteur_cm());
        commandeEntity.setLargeur_cm(old_commande.getLargeur_cm());
        commandeEntity.setLongueur_cm(old_commande.getLongueur_cm());
        commandeEntity.setGouvernoratCmd(old_commande.getGouvernoratCmd());
        commandeEntity.setIspaied(old_commande.getIspaied());

        // Mettre à jour les champs fournis
        if (statut_commande != null && !statut_commande.isEmpty()) {
            commandeEntity.setStatut_commande(statut_commande);
            logger.info("Statut_commande mis à jour: {}", statut_commande);
        }

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss");
        try {
            if (date_expidetion != null && !date_expidetion.isEmpty()) {
                commandeEntity.setDate_expidetion(LocalDateTime.parse(date_expidetion, formatter));
                logger.info("Date_expidetion mis à jour: {}", date_expidetion);
            }
            if (date_livree != null && !date_livree.isEmpty()) {
                commandeEntity.setDate_livree(LocalDateTime.parse(date_livree, formatter));
                logger.info("Date_livree mis à jour: {}", date_livree);
            }
        } catch (DateTimeParseException e) {
            logger.error("Erreur de parsing de la date: {}", e.getMessage());
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Format de date invalide. Utilisez yyyy-MM-dd'T'HH:mm:ss");
        }

        // Mettre à jour la commande
        try {
            CommandeEntity cmd = commandeService.update(commandeEntity);
            logger.info("Commande mise à jour avec succès pour l'ID: {}", id_commande);
            return new CommandeDTO().fromEntity(cmd);
        } catch (Exception e) {
            logger.error("Erreur lors de la mise à jour de la commande: {}", e.getMessage(), e);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Erreur lors de la mise à jour de la commande: " + e.getMessage());
        }
    }

   */






    @GetMapping("/allByLivreurID/{idlivreur}")
    public List<CommandeDTO> getAllByLivreurID(@PathVariable Long idlivreur) {
        List<CommandeEntity> commandes = commandeService.alltasksbyIdLivreur(idlivreur);
        List<CommandeDTO> commandeDTOs = new ArrayList<>();

        for (CommandeEntity commande : commandes) {
            CommandeDTO commandeDTO = new CommandeDTO().fromEntity(commande);

            // Affecter les identifiants nécessaires
            commandeDTO.setId_commande(commande.getId_commande());
            commandeDTO.setIduser(commande.getIduser());
            commandeDTO.setIdproduit(commande.getIdproduit());
            commandeDTO.setLivreurId(commande.getLivreurId());
            commandeDTO.setGouvernoratCmd(commande.getGouvernoratCmd());

            // Récupérer les informations de l'utilisateur et du produit
            if (commande.getIduser() != null) {
                try {
                    UserDTO userDTO = commande_user.getUser(commande.getIduser());
                    commandeDTO.setUserDTO(userDTO);
                } catch (FeignException.NotFound e) {
                    System.err.println("Utilisateur non trouvé pour la commande ID: " + commande.getId_commande());
                }
            }

            if (commande.getIdproduit() != null) {
                try {
                    ProductDTO productDTO = client_product.getProduct(commande.getIdproduit());
                    commandeDTO.setProductDTO(productDTO);
                } catch (FeignException.NotFound e) {
                    System.err.println("Produit non trouvé pour la commande ID: " + commande.getId_commande());
                }
            }

            commandeDTOs.add(commandeDTO);
        }

        return commandeDTOs;
    }

    @GetMapping("/allByproductID/{idProject}")
    public List<CommandeDTO> getAllByProductID(@PathVariable Long idProject) {
        List<CommandeEntity> commandes = commandeService.alltasksbyIdproduct(idProject);
        List<CommandeDTO> commandeDTOs = new ArrayList<>();

        for (CommandeEntity commande : commandes) {
            CommandeDTO commandeDTO = new CommandeDTO().fromEntity(commande);

            commandeDTO.setId_commande(commande.getId_commande());
            commandeDTO.setIdproduit(commande.getIdproduit());
            commandeDTO.setIduser(commande.getIduser());
            commandeDTO.setLivreurId(commande.getLivreurId());
            commandeDTO.setGouvernoratCmd(commande.getGouvernoratCmd());
            // Récupérer et affecter le ProductDTO
            ProductDTO productDTO = client_product.getProduct(idProject);
            commandeDTO.setProductDTO(productDTO);

            // Supprimer complètement l'objet userDTO
            commandeDTO.setUserDTO(null);
            commandeDTOs.add(commandeDTO);
        }

        return commandeDTOs;
    }



    @GetMapping("/allByUserID/{iduser}")
    public List<CommandeDTO> getAllByUserID(@PathVariable Long iduser) {
        List<CommandeEntity> commandes = commandeService.alltasksbyIduser(iduser);
        List<CommandeDTO> commandeDTOs = new ArrayList<>();

        for (CommandeEntity commande : commandes) {
            CommandeDTO commandeDTO = new CommandeDTO().fromEntity(commande);

            // Affecter les identifiants nécessaires
            commandeDTO.setId_commande(commande.getId_commande());
            commandeDTO.setIduser(commande.getIduser());
            commandeDTO.setIdproduit(commande.getIdproduit());
            commandeDTO.setLivreurId(commande.getLivreurId());
            commandeDTO.setGouvernoratCmd(commande.getGouvernoratCmd());

            // Récupérer uniquement l'utilisateur (pas le produit)
            UserDTO userDTO = commande_user.getUser(commande.getIduser());
            commandeDTO.setUserDTO(userDTO);

            commandeDTOs.add(commandeDTO);
        }

        return commandeDTOs;
    }


    @PostMapping("/createuser/{iduser}")
    public CommandeDTO addCommandeUser(
            @ModelAttribute CommandeEntity commandeEntity, // ← ici @ModelAttribute au lieu de @RequestBody
            @PathVariable Long iduser) {

        UserDTO userDTO = commande_user.getUser(iduser);
        //  ProductDTO productDTO = client_product.getProduct(idproduit);

        // Créer la commande avec le service
        CommandeEntity x = commandeService.create(commandeEntity);

        x.setIduser(iduser);
        x.setUserDTO(userDTO);
        // x.setIdproduit(idproduit);
        //   x.setProductDTO(productDTO);

        CommandeDTO commandeDTO = new CommandeDTO().fromEntity(x);
        //    commandeDTO.setIdproduit(idproduit);
        commandeDTO.setUserDTO(userDTO);
        // commandeDTO.setProductDTO(productDTO);

        return commandeDTO;
    }

    /* @PostMapping("/createUP/{iduser}/{idproduit}")
     public CommandeDTO addCommandeUser(
             @ModelAttribute CommandeEntity commandeEntity,
             @PathVariable Long iduser,
             @PathVariable Long idproduit) {

         UserDTO userDTO = commande_user.getUser(iduser);
         ProductDTO productDTO = client_product.getProduct(idproduit);

         // Préparer l’objet complet
         commandeEntity.setIduser(iduser);
         commandeEntity.setUserDTO(userDTO);
         commandeEntity.setIdproduit(idproduit);
         commandeEntity.setProductDTO(productDTO);

         // Ensuite, enregistrer dans la base
         CommandeEntity x = commandeService.create(commandeEntity);

         // Préparer le DTO à retourner
         CommandeDTO commandeDTO = new CommandeDTO().fromEntity(x);
         commandeDTO.setIdproduit(idproduit);
         commandeDTO.setUserDTO(userDTO);
         commandeDTO.setProductDTO(productDTO);

         return commandeDTO;
     }
   */
    @GetMapping("/getAll")
    public ResponseEntity<List<CommandeDTO>> getAll() {
        List<CommandeEntity> commandes = commandeService.GetAll();
        List<CommandeDTO> commandeDTOs = new ArrayList<>();

        for (CommandeEntity commande : commandes) {
            // Convert entity to DTO
            CommandeDTO dto = new CommandeDTO().fromEntity(commande);
            dto.setIduser(commande.getIduser());
            dto.setIdproduit(commande.getIdproduit());

            // Log commande details for debugging
            System.out.println("Processing commande ID: " + commande.getId_commande() +
                    ", iduser: " + commande.getIduser() +
                    ", idproduit: " + commande.getIdproduit());

            // Fetch UserDTO if iduser is not null
            if (commande.getIduser() != null) {
                try {
                    UserDTO userDTO = commande_user.getUser(commande.getIduser());
                    if (userDTO != null) {
                        dto.setUserDTO(userDTO);
                        System.out.println("Successfully fetched UserDTO for iduser: " +
                                commande.getIduser() + ": " + userDTO);
                    } else {
                        System.err.println("UserDTO is null for iduser: " + commande.getIduser() +
                                " in commande ID: " + commande.getId_commande());
                        dto.setUserDTO(null);
                    }
                } catch (FeignException.NotFound e) {
                    System.err.println("User not found for iduser: " + commande.getIduser() +
                            " in commande ID: " + commande.getId_commande() +
                            ". Error: " + e.getMessage());
                    dto.setUserDTO(null);
                } catch (Exception e) {
                    System.err.println("Error fetching UserDTO for iduser: " + commande.getIduser() +
                            " in commande ID: " + commande.getId_commande() +
                            ". Error: " + e.getMessage());
                    dto.setUserDTO(null);
                }
            } else {
                System.out.println("iduser is null for commande ID: " + commande.getId_commande());
                dto.setUserDTO(null);
            }

            // Fetch ProductDTO if idproduit is not null
            if (commande.getIdproduit() != null) {
                try {
                    ProductDTO productDTO = client_product.getProduct(commande.getIdproduit());
                    if (productDTO != null) {
                        dto.setProductDTO(productDTO);
                        System.out.println("Successfully fetched ProductDTO for idproduit: " +
                                commande.getIdproduit());
                    } else {
                        System.err.println("ProductDTO is null for idproduit: " + commande.getIdproduit() +
                                " in commande ID: " + commande.getId_commande());
                        dto.setProductDTO(null);
                    }
                } catch (FeignException.NotFound e) {
                    System.err.println("Product not found for idproduit: " + commande.getIdproduit() +
                            " in commande ID: " + commande.getId_commande() +
                            ". Error: " + e.getMessage());
                    dto.setProductDTO(null);
                } catch (Exception e) {
                    System.err.println("Error fetching ProductDTO for idproduit: " + commande.getIdproduit() +
                            " in commande ID: " + commande.getId_commande() +
                            ". Error: " + e.getMessage());
                    dto.setProductDTO(null);
                }
            } else {
                System.out.println("idproduit is null for commande ID: " + commande.getId_commande());
                dto.setProductDTO(null);
            }

            commandeDTOs.add(dto);
        }

        // Log the number of commands returned
        System.out.println("Returning " + commandeDTOs.size() + " commandes");
        return ResponseEntity.ok(commandeDTOs);
    }
    @GetMapping("/getcmd/{id_commande}")
    public CommandeDTO getCommande(@PathVariable Long id_commande) {
        // Récupération de la commande depuis le service
        CommandeEntity c = commandeService.one_commande(id_commande);
        if (c == null) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Commande non trouvée");
        }

        // Transformation de l'entité en DTO
        CommandeDTO commandeDTO = new CommandeDTO().fromEntity(c);

        // Ajout des informations iduser, idproduit, et livreurId
        commandeDTO.setIduser(c.getIduser());
        commandeDTO.setIdproduit(c.getIdproduit());
        commandeDTO.setLivreurId(c.getLivreurId());

        // Récupération de userDTO si iduser n'est pas null
        if (c.getIduser() != null) {
            try {
                UserDTO userDTO = commande_user.getUser(c.getIduser());
                commandeDTO.setUserDTO(userDTO);
                System.out.println("userDTO récupéré pour iduser " + c.getIduser() + ": " + userDTO);
            } catch (FeignException.NotFound e) {
                System.err.println("Utilisateur non trouvé pour iduser: " + c.getIduser() + " (Commande ID: " + c.getId_commande() + ")");
            } catch (Exception e) {
                System.err.println("Erreur inattendue lors de la récupération de userDTO pour iduser: " + c.getIduser() + " - " + e.getMessage());
            }
        } else {
            System.err.println("iduser est null pour la commande ID: " + c.getId_commande());
        }

        // Récupération de productDTO si idproduit n'est pas null
        if (c.getIdproduit() != null) {
            try {
                ProductDTO productDTO = client_product.getProduct(c.getIdproduit());
                commandeDTO.setProductDTO(productDTO);
                System.out.println("productDTO récupéré pour idproduit " + c.getIdproduit() + ": " + productDTO);
            } catch (FeignException.NotFound e) {
                System.err.println("Produit non trouvé pour idproduit: " + c.getIdproduit() + " (Commande ID: " + c.getId_commande() + ")");
            } catch (Exception e) {
                System.err.println("Erreur inattendue lors de la récupération de productDTO pour idproduit: " + c.getIdproduit() + " - " + e.getMessage());
            }
        } else {
            System.err.println("idproduit est null pour la commande ID: " + c.getId_commande());
        }

        return commandeDTO;
    }




/*

   @PutMapping("/assignLivreur/{idcommande}/{idlivreur}")
    public CommandeDTO assignLivreurToCommande(
            @PathVariable Long idcommande,
            @PathVariable Long idlivreur) {

        // Récupère la commande existante
        CommandeEntity commande = commandeService.findById(idcommande);
        if (commande == null) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Commande introuvable");
        }

        // Récupère le livreur
        UserDTO livreurDTO = commande_user.getUser(idlivreur);

        // Associe le livreur
        commande.setLivreurId(idlivreur);
        commande.setUserDTO(livreurDTO);

        // Sauvegarde la mise à jour
        CommandeEntity updatedCommande = commandeService.update(commande);

        // Retourne la commande mise à jour sous forme de DTO
        CommandeDTO commandeDTO = new CommandeDTO().fromEntity(updatedCommande);
        commandeDTO.setUserDTO(livreurDTO);
        commandeDTO.setLivreurId(idlivreur);

        return commandeDTO;
    }*/


    @PutMapping("/assignLivreur/{idcommande}/{idlivreur}")
    public CommandeDTO assignLivreurToCommande(
            @PathVariable Long idcommande,
            @PathVariable Long idlivreur,
            @RequestParam("date_affection") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime dateAffection) {

        System.out.println("Date d'affectation reçue : " + dateAffection);

        // Ajuster la date en ajoutant 1 heure pour compenser le décalage
        LocalDateTime adjustedDateAffection = dateAffection.plusHours(1);
        System.out.println("Date d'affectation ajustée : " + adjustedDateAffection);

        // Récupère la commande existante
        CommandeEntity commande = commandeService.findById(idcommande);
        if (commande == null) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Commande introuvable");
        }

        // Récupère le livreur
        UserDTO livreurDTO = commande_user.getUser(idlivreur);

        // Associe le livreur et la date d'affectation
        commande.setLivreurId(idlivreur);
        commande.setUserDTO(livreurDTO);
        commande.setDate_affection(adjustedDateAffection);

        System.out.println("Date d'affectation avant sauvegarde : " + commande.getDate_affection());

        // Sauvegarde la mise à jour
        CommandeEntity updatedCommande = commandeService.updateD(commande);

        System.out.println("Date d'affectation après sauvegarde : " + updatedCommande.getDate_affection());

        // Prépare le DTO pour le retour
        CommandeDTO commandeDTO = new CommandeDTO().fromEntity(updatedCommande);
        commandeDTO.setUserDTO(livreurDTO);
        commandeDTO.setLivreurId(idlivreur);

        return commandeDTO;
    }

/*
    @PutMapping("/assignLivreur/{idcommande}/{idlivreur}")
    public CommandeDTO assignLivreurToCommande(
            @PathVariable Long idcommande,
            @PathVariable Long idlivreur,
            @RequestParam(required = false) String date_affection) {

        // Récupère la commande existante
        CommandeEntity commande = commandeService.findById(idcommande);
        if (commande == null) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Commande introuvable");
        }

        // Vérifie si l'ID du livreur est valide
        if (idlivreur == null || idlivreur == 0) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "ID du livreur invalide");
        }

        // Récupère le livreur
        UserDTO livreurDTO = commande_user.getUser(idlivreur);
        if (livreurDTO == null) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Livreur introuvable");
        }

        // Met à jour les champs de la commande
        commande.setLivreurId(idlivreur);
        commande.setUserDTO(livreurDTO);

        // Remplir la date d'affectation avec la date et l'heure actuelles à Tunis
        LocalDateTime dateAffectation = ZonedDateTime.now(ZoneId.of("Africa/Tunis")).toLocalDateTime();
        logger.info("Date d'affectation générée (Africa/Tunis) : {}", dateAffectation);
        commande.setDate_affection(dateAffectation);

        // Sauvegarde la mise à jour
        CommandeEntity updatedCommande = commandeService.update(commande);
        logger.info("Date d'affectation après enregistrement : {}", updatedCommande.getDate_affection());

        // Prépare le DTO pour le retour
        CommandeDTO commandeDTO = new CommandeDTO().fromEntity(updatedCommande);
        commandeDTO.setUserDTO(livreurDTO);
        commandeDTO.setLivreurId(idlivreur);

        return commandeDTO;
    }*/



    /*

    @PutMapping("/orders/{orderId}/status")
    public CommandeEntity updateOrderStatus(@PathVariable Long orderId, @RequestBody String newStatus) {
        // Mettre à jour le statut de la commande
        CommandeEntity order = commandeService.updateOrderStatus(orderId, newStatus);

        // Envoyer une notification au client associé
        String message = "Votre commande #" + orderId + " est maintenant " + newStatus;
        notificationService.sendNotificationToUser(order.getIduser(), message);

        return order;
    }



    @PutMapping("/orders/{orderId}/status")
    public CommandeEntity updateOrderStatusH(@PathVariable Long id_commande, @RequestParam("statut_commande") String statut_commande) {
        // Mettre à jour le statut de la commande
        CommandeEntity order = commandeService.findById(id_commande);
        if (order == null) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Commande introuvable");
        }

        order.setStatut_commande(statut_commande);
        if (statut_commande.equals("Out for delivery")) {
            order.setDate_expidetion(LocalDateTime.now()); // Mise à jour de la date d'expédition
        }

        CommandeEntity updatedOrder = commandeService.update(order);

        // Envoyer une notification au client associé
        String message = "Votre commande #" + id_commande + " est maintenant " + statut_commande;
        notificationService.sendNotificationToUser(order.getIduser(), message);

        return updatedOrder;
    }





 */
@PutMapping(value = "/archive/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
public ResponseEntity<Void> archiveCommande(@PathVariable Long id) {
    try {
        commandeService.archiveCommande(id);
        return ResponseEntity.ok().build();
    } catch (Exception e) {
        throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Erreur lors de l'archivage de la commande", e);
    }
}

    // Unarchive a command
    @PutMapping(value = "/unarchive/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Void> unarchiveCommande(@PathVariable Long id) {
        try {
            commandeService.unarchiveCommande(id);
            return ResponseEntity.ok().build();
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Erreur lors du désarchivage de la commande", e);
        }
    }

    // Get active commands for a user
    @GetMapping(value = "/client/{iduser}/active", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<CommandeDTO>> getActiveCommandes(@PathVariable Long iduser) {
        List<CommandeEntity> commandes = commandeService.getActiveCommandes(iduser);
        List<CommandeDTO> commandeDTOs = commandes.stream()
                .map(commande -> {
                    CommandeDTO dto = new CommandeDTO().fromEntity(commande);
                    dto.setIduser(commande.getIduser());
                    dto.setIdproduit(commande.getIdproduit());
                    dto.setLivreurId(commande.getLivreurId());
                    if (commande.getIduser() != null) {
                        try {
                            UserDTO userDTO = commande_user.getUser(commande.getIduser());
                            dto.setUserDTO(userDTO);
                        } catch (FeignException.NotFound e) {
                            System.err.println("Utilisateur non trouvé pour la commande ID: " + commande.getId_commande());
                        }
                    }
                    if (commande.getIdproduit() != null) {
                        try {
                            ProductDTO productDTO = client_product.getProduct(commande.getIdproduit());
                            dto.setProductDTO(productDTO);
                        } catch (FeignException.NotFound e) {
                            System.err.println("Produit non trouvé pour la commande ID: " + commande.getId_commande());
                        }
                    }
                    return dto;
                })
                .collect(Collectors.toList());
        return ResponseEntity.ok(commandeDTOs);
    }




    // Get archived commands for a user
    @GetMapping(value = "/client/{iduser}/archived", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<CommandeDTO>> getArchivedCommandes(@PathVariable Long iduser) {
        List<CommandeEntity> commandes = commandeService.getArchivedCommandes(iduser);
        List<CommandeDTO> commandeDTOs = commandes.stream()
                .map(commande -> {
                    CommandeDTO dto = new CommandeDTO().fromEntity(commande);
                    dto.setIduser(commande.getIduser());
                    dto.setIdproduit(commande.getIdproduit());
                    dto.setLivreurId(commande.getLivreurId());
                    if (commande.getIduser() != null) {
                        try {
                            UserDTO userDTO = commande_user.getUser(commande.getIduser());
                            dto.setUserDTO(userDTO);
                        } catch (FeignException.NotFound e) {
                            System.err.println("Utilisateur non trouvé pour la commande ID: " + commande.getId_commande());
                        }
                    }
                    if (commande.getIdproduit() != null) {
                        try {
                            ProductDTO productDTO = client_product.getProduct(commande.getIdproduit());
                            dto.setProductDTO(productDTO);
                        } catch (FeignException.NotFound e) {
                            System.err.println("Produit non trouvé pour la commande ID: " + commande.getId_commande());
                        }
                    }
                    return dto;
                })
                .collect(Collectors.toList());
        return ResponseEntity.ok(commandeDTOs);
    }



    // Moved livreur-specific endpoints from EvaluationRequest to CommandeController
    @GetMapping(value = "/livreur/{idlivreur}/active", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<CommandeDTO>> getActiveCommandesByLivreur(@PathVariable Long idlivreur) {
        List<CommandeEntity> commandes = commandeService.getActiveCommandesByLivreur(idlivreur);
        List<CommandeDTO> commandeDTOs = commandes.stream()
                .map(commande -> {
                    CommandeDTO dto = new CommandeDTO().fromEntity(commande);
                    dto.setIduser(commande.getIduser());
                    dto.setIdproduit(commande.getIdproduit());
                    dto.setLivreurId(commande.getLivreurId());
                    if (commande.getIduser() != null) {
                        try {
                            UserDTO userDTO = commande_user.getUser(commande.getIduser());
                            dto.setUserDTO(userDTO);
                        } catch (FeignException.NotFound e) {
                            System.err.println("Utilisateur non trouvé pour la commande ID: " + commande.getId_commande());
                        }
                    }
                    if (commande.getIdproduit() != null) {
                        try {
                            ProductDTO productDTO = client_product.getProduct(commande.getIdproduit());
                            dto.setProductDTO(productDTO);
                        } catch (FeignException.NotFound e) {
                            System.err.println("Produit non trouvé pour la commande ID: " + commande.getId_commande());
                        }
                    }
                    return dto;
                })
                .collect(Collectors.toList());
        return ResponseEntity.ok(commandeDTOs);
    }

    @GetMapping(value = "/livreur/{idlivreur}/archived", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<CommandeDTO>> getArchivedCommandesByLivreur(@PathVariable Long idlivreur) {
        List<CommandeEntity> commandes = commandeService.getArchivedCommandesByLivreur(idlivreur);
        List<CommandeDTO> commandeDTOs = commandes.stream()
                .map(commande -> {
                    CommandeDTO dto = new CommandeDTO().fromEntity(commande);
                    dto.setIduser(commande.getIduser());
                    dto.setIdproduit(commande.getIdproduit());
                    dto.setLivreurId(commande.getLivreurId());
                    if (commande.getIduser() != null) {
                        try {
                            UserDTO userDTO = commande_user.getUser(commande.getIduser());
                            dto.setUserDTO(userDTO);
                        } catch (FeignException.NotFound e) {
                            System.err.println("Utilisateur non trouvé pour la commande ID: " + commande.getId_commande());
                        }
                    }
                    if (commande.getIdproduit() != null) {
                        try {
                            ProductDTO productDTO = client_product.getProduct(commande.getIdproduit());
                            dto.setProductDTO(productDTO);
                        } catch (FeignException.NotFound e) {
                            System.err.println("Produit non trouvé pour la commande ID: " + commande.getId_commande());
                        }
                    }
                    return dto;
                })
                .collect(Collectors.toList());
        return ResponseEntity.ok(commandeDTOs);
    }




    // Ajouter une évaluation à une commande
    @PutMapping(value = "/evaluate/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CommandeDTO> evaluateCommande(
            @PathVariable Long id,
            @RequestBody EvaluationRequest evaluationRequest) {
        try {
            CommandeEntity updatedCommande = commandeService.addEvaluation(
                    id,
                    evaluationRequest.getNoteClient(),
                    evaluationRequest.getCommentaireClient(),
                    evaluationRequest.getUserId()
            );
            CommandeDTO commandeDTO = new CommandeDTO().fromEntity(updatedCommande);
            // Récupérer les DTOs associés
            if (updatedCommande.getIduser() != null && updatedCommande.getIdproduit() != null) {
                try {
                    UserDTO userDTO = commande_user.getUser(updatedCommande.getIduser());
                    ProductDTO productDTO = client_product.getProduct(updatedCommande.getIdproduit());
                    commandeDTO.setUserDTO(userDTO);
                    commandeDTO.setProductDTO(productDTO);
                } catch (FeignException.NotFound e) {
                    System.err.println("Produit ou utilisateur non trouvé pour la commande ID: " + updatedCommande.getId_commande());
                }
            }
            return ResponseEntity.ok(commandeDTO);
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage(), e);
        }
    }



    // Classe interne pour la requête d'évaluation
    static class EvaluationRequest {
        private Float noteClient;
        private String commentaireClient;
        private Long userId;

        public Float getNoteClient() {
            return noteClient;
        }

        public void setNoteClient(Float noteClient) {
            this.noteClient = noteClient;
        }

        public String getCommentaireClient() {
            return commentaireClient;
        }

        public void setCommentaireClient(String commentaireClient) {
            this.commentaireClient = commentaireClient;
        }

        public Long getUserId() {
            return userId;
        }

        public void setUserId(Long userId) {
            this.userId = userId;
        }
    }




    @PutMapping("/updatecmd/{id_commande}")
    public CommandeDTO update(
            @PathVariable Long id_commande,
            @RequestParam(required = false) String statut_commande
    ) {
        logger.info("Requête PUT reçue pour updatecmd/{} avec statut_commande: '{}'", id_commande, statut_commande);

        // Vérifier si la commande existe
        CommandeEntity commandeEntity = commandeService.one_commande(id_commande);
        if (commandeEntity == null) {
            logger.error("Commande introuvable pour l'ID: {}", id_commande);
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Commande introuvable pour l'ID: " + id_commande);
        }

        // Vérifier le statut_commande
        if (statut_commande == null || statut_commande.trim().isEmpty()) {
            logger.warn("statut_commande est null ou vide pour l'ID: {}", id_commande);
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Le statut_commande est requis");
        }

        // Normaliser le statut pour éviter les problèmes de casse ou d'espaces
        String normalizedStatut = statut_commande.trim().toUpperCase();
        logger.info("Statut normalisé: {}", normalizedStatut);

        // Mettre à jour le statut et les dates associées
        commandeEntity.setStatut_commande(normalizedStatut);
        logger.info("Statut_commande mis à jour: {}", normalizedStatut);

        LocalDateTime now = LocalDateTime.now();
        if ("IN_TRANSIT".equals(normalizedStatut)) {
            commandeEntity.setDate_expidetion(now);
            logger.info("Date_expidetion définie à: {}", now);
        } else if ("DELIVERED".equals(normalizedStatut) || "CANCELLED".equals(normalizedStatut)) {
            commandeEntity.setDate_livree(now);
            logger.info("Date_livree définie à: {}", now);
        } else {
            logger.warn("Statut non reconnu: {}", normalizedStatut);
        }

        // Vérifier l'état de l'entité avant sauvegarde
        logger.info("Avant sauvegarde - date_expidetion: {}", commandeEntity.getDate_expidetion());

        // Mettre à jour la commande
        try {
            CommandeEntity updatedCommande = commandeService.update(commandeEntity);
            logger.info("Après sauvegarde - date_expidetion: {}", updatedCommande.getDate_expidetion());

            // Vérifier que iduser est non null
            if (updatedCommande.getIduser() == null) {
                logger.error("iduser est null pour la commande: {}", id_commande);
                throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "iduser est null pour la commande: " + id_commande);
            }

            // Envoyer une notification
            String notificationUrl = "http://localhost:8080/notify/order-update";
            OrderUpdate notification = new OrderUpdate();
            notification.setOrderId(id_commande.toString());
            notification.setStatus(normalizedStatut);
            notification.setIduser(updatedCommande.getIduser());
            notification.setArticelCommande(updatedCommande.getArticel_commande());
            notification.setAdresseLivraison(updatedCommande.getAdresse_livraison());
            notification.setDateCommande(updatedCommande.getDateCommande() != null ? updatedCommande.getDateCommande().toString() : null);

            try {
                restTemplate.postForObject(notificationUrl, notification, Void.class);
                logger.info("Notification envoyée pour iduser: {}", updatedCommande.getIduser());
            } catch (RestClientException e) {
                logger.error("Erreur lors de l'envoi de la notification: {}", e.getMessage());
            }

            return new CommandeDTO().fromEntity(updatedCommande);
        } catch (Exception e) {
            logger.error("Erreur lors de la mise à jour de la commande {}: {}", id_commande, e.getMessage());
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Erreur lors de la mise à jour de la commande");
        }
    }




    @PostMapping("/creer")
    public ResponseEntity<CommandeEntity> creerCommande(
            @RequestBody CommandeEntity commande,
            @RequestParam boolean isExpress,
            @RequestParam boolean isWeekend) {

        CommandeEntity savedCommande = commandeService.creerCommande(commande, isExpress, isWeekend);
        return ResponseEntity.ok(savedCommande);
    }

     /*       ::::::
       @PutMapping("/updatecmd/{id_commande}")
        public CommandeDTO update(
                @PathVariable Long id_commande,
                @RequestParam(required = false) String statut_commande,
                @RequestParam(required = false) String date_expidetion,
                @RequestParam(required = false) String date_livree,
                @RequestHeader("Authorization") String authHeader
        ) {
            logger.info("Requête PUT reçue pour updatecmd/{} avec statut_commande: {}, date_expidetion: {}, date_livree: {}",
                    id_commande, statut_commande, date_expidetion, date_livree);

            // Récupérer l'ancienne commande
            CommandeEntity old_commande = commandeService.one_commande(id_commande);
            if (old_commande == null) {
                logger.error("Commande introuvable pour l'ID: {}", id_commande);
                throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Commande introuvable pour l'ID: " + id_commande);
            }

            // Créer une nouvelle instance de CommandeEntity avec les anciennes valeurs
            CommandeEntity commandeEntity = new CommandeEntity();
            commandeEntity.setId_commande(id_commande);
            commandeEntity.setStatut_commande(old_commande.getStatut_commande());
            commandeEntity.setArticel_commande(old_commande.getArticel_commande());
            commandeEntity.setDateCommande(old_commande.getDateCommande());
            commandeEntity.setCommentaires(old_commande.getCommentaires());
            commandeEntity.setAdresse_livraison(old_commande.getAdresse_livraison());
            commandeEntity.setDate_livraison_estimee(old_commande.getDate_livraison_estimee());
            commandeEntity.setFraisLivraison(old_commande.getFraisLivraison());
            commandeEntity.setRemise(old_commande.getRemise());
            commandeEntity.setTotal(old_commande.getTotal());
            commandeEntity.setLatitude(old_commande.getLatitude());
            commandeEntity.setLongitude(old_commande.getLongitude());
            commandeEntity.setLivreurId(old_commande.getLivreurId());
            commandeEntity.setEnseigne(old_commande.getEnseigne());
            commandeEntity.setDate_ajoutsystem(old_commande.getDate_ajoutsystem());
            commandeEntity.setDate_affection(old_commande.getDate_affection());
            commandeEntity.setDate_expidetion(old_commande.getDate_expidetion());
            commandeEntity.setDate_livree(old_commande.getDate_livree());
            commandeEntity.setDestination_enseigne(old_commande.getDestination_enseigne());
            commandeEntity.setPoids_grammes(old_commande.getPoids_grammes());
            commandeEntity.setHauteur_cm(old_commande.getHauteur_cm());
            commandeEntity.setLargeur_cm(old_commande.getLargeur_cm());
            commandeEntity.setLongueur_cm(old_commande.getLongueur_cm());
            commandeEntity.setGouvernoratCmd(old_commande.getGouvernoratCmd());
            commandeEntity.setIspaied(old_commande.getIspaied());
            commandeEntity.setIduser(old_commande.getIduser());
            commandeEntity.setIdpartenaire(old_commande.getIdpartenaire());
            commandeEntity.setFixe_temps(old_commande.getFixe_temps());


            // Mettre à jour les champs fournis
            if (statut_commande != null && !statut_commande.isEmpty()) {
                commandeEntity.setStatut_commande(statut_commande);
                logger.info("Statut_commande mis à jour: {}", statut_commande);
            }

            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss");
            try {
                if (date_expidetion != null && !date_expidetion.isEmpty()) {
                    commandeEntity.setDate_expidetion(LocalDateTime.parse(date_expidetion, formatter));
                    logger.info("Date_expidetion mis à jour: {}", date_expidetion);
                }
                if (date_livree != null && !date_livree.isEmpty()) {
                    commandeEntity.setDate_livree(LocalDateTime.parse(date_livree, formatter));
                    logger.info("Date_livree mis à jour: {}", date_livree);
                }
            } catch (DateTimeParseException e) {
                logger.error("Erreur de parsing de la date: {}", e.getMessage());
                throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Format de date invalide. Utilisez yyyy-MM-dd'T'HH:mm:ss");
            }

            // Mettre à jour la commande
            try {
                CommandeEntity updatedCommande = commandeService.update(commandeEntity);
                logger.info("Commande mise à jour avec succès pour l'ID: {}", id_commande);

                // Envoyer la notification à RealTime24
                OrderUpdate update = new OrderUpdate();
                update.setOrderId(updatedCommande.getId_commande().toString());
                update.setStatus(updatedCommande.getStatut_commande());
                update.setIduser(updatedCommande.getIduser());
                update.setIdpartenaire(updatedCommande.getIdpartenaire());
                update.setArticelCommande(updatedCommande.getArticel_commande());
                update.setAdresseLivraison(updatedCommande.getAdresse_livraison());
                update.setDateCommande(updatedCommande.getDateCommande() != null
                        ? updatedCommande.getDateCommande().format(DateTimeFormatter.ofPattern("yyyy-MM-dd"))
                        : null);

                HttpHeaders headers = new HttpHeaders();
                headers.set("Authorization", authHeader);
                HttpEntity<OrderUpdate> request = new HttpEntity<>(update, headers);
                logger.debug("Envoi de la notification à {} avec Authorization: {} et body: {}", notifyUrl, authHeader, update);
                try {
                    restTemplate.postForObject(notifyUrl, request, Void.class);
                    logger.info("Notification envoyée à RealTime24 pour commande ID: {}", id_commande);
                } catch (HttpClientErrorException e) {
                    logger.error("Échec de l'envoi de la notification à RealTime24: {} {}, Response: {}",
                            e.getStatusCode(), e.getStatusText(), e.getResponseBodyAsString());
                    throw new ResponseStatusException(
                            HttpStatus.BAD_GATEWAY,
                            "Échec de l'envoi de la notification à RealTime24: " + e.getStatusCode() + " " + e.getStatusText()
                    );
                } catch (RestClientException e) {
                    logger.error("Erreur lors de l'envoi de la notification à RealTime24: {}", e.getMessage());
                    throw new ResponseStatusException(
                            HttpStatus.BAD_GATEWAY,
                            "Erreur lors de l'envoi de la notification à RealTime24: " + e.getMessage()
                    );
                }

                return new CommandeDTO().fromEntity(updatedCommande);
            } catch (Exception e) {
                logger.error("Erreur lors de la mise à jour de la commande: {}", e.getMessage(), e);
                throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Erreur lors de la mise à jour de la commande: " + e.getMessage());
            }
        }

      */

    @GetMapping("/partner/{partnerId}")
    public ResponseEntity<List<CommandeEntity>> getOrdersByPartnerId(@PathVariable Long partnerId) {
        List<CommandeEntity> orders = commandeService.getOrdersByPartnerId(partnerId);
        if (orders.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(orders);
    }


    @PostMapping("/invoice/{orderId}")
    public ResponseEntity<Map<String, String>> storeInvoice(
            @PathVariable Long orderId,
            @RequestParam("invoice") MultipartFile invoiceFile,
            @RequestParam("orderId") String orderIdParam) {
        try {
            String invoiceUrl = commandeService.storeInvoice(orderId, invoiceFile);
            Map<String, String> response = new HashMap<>();
            response.put("invoiceUrl", invoiceUrl);
            return ResponseEntity.ok(response);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(404).body(Map.of("error", e.getMessage()));
        } catch (IOException e) {
            return ResponseEntity.status(500).body(Map.of("error", "Failed to store invoice: " + e.getMessage()));
        }
    }




    }












