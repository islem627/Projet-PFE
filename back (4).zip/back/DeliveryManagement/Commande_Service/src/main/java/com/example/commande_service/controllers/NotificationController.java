package com.example.commande_service.controllers;


import com.example.commande_service.entities.PrivateMessage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Controller;

@Controller
public class NotificationController {

    //server application
    ///app/sendMessage
    ///app/sendMessage
    @MessageMapping("/sendMessage")
    @SendTo("/topic/notifications")
    public String sendMessage(String message){
        System.out.println("message : "+message);
        return message;
    }

//
//    @Autowired
//    private SimpMessagingTemplate messagingTemplate;
//
//    public void sendPrivateNotification(String userId, String message) {
//        messagingTemplate.convertAndSendToUser(userId, "/queue/notifications", message);
//    }


//
//    @MessageMapping("/sendPrivateMessage")
//    public void sendPrivateMessage(@Payload PrivateMessage privateMessage) {
//        String userId = privateMessage.getUserId(); // the receiver
//        String message = privateMessage.getMessage();
//
//        System.out.println("Sending private message to user " + userId + ": " + message);
//
//        messagingTemplate.convertAndSendToUser(userId, "/queue/notifications", message);
//    }



}