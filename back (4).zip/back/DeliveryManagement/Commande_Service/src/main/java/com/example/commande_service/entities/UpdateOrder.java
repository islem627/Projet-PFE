package com.example.commande_service.entities;

class OrderUpdate {
    private String orderId;
    private String status;
    private Long iduser;
    private String articelCommande;
    private String adresseLivraison;
    private String dateCommande;

    // Getters et setters
    public String getOrderId() { return orderId; }
    public void setOrderId(String orderId) { this.orderId = orderId; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public Long getIduser() { return iduser; }
    public void setIduser(Long iduser) { this.iduser = iduser; }
    public String getArticelCommande() { return articelCommande; }
    public void setArticelCommande(String articelCommande) { this.articelCommande = articelCommande; }
    public String getAdresseLivraison() { return adresseLivraison; }
    public void setAdresseLivraison(String adresseLivraison) { this.adresseLivraison = adresseLivraison; }
    public String getDateCommande() { return dateCommande; }
    public void setDateCommande(String dateCommande) { this.dateCommande = dateCommande; }
}
