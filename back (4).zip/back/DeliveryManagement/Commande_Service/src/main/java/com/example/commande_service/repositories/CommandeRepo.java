package com.example.commande_service.repositories;

import com.example.commande_service.entities.CommandeEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository

    public interface CommandeRepo extends JpaRepository<CommandeEntity, Long> {
    @Query("SELECT t FROM CommandeEntity t WHERE t.idproduit = :id")
    public List<CommandeEntity> findAllByProject_Id(Long id);
    @Query("SELECT i FROM CommandeEntity i WHERE i.iduser = :id")
    public List<CommandeEntity>findAllByUser_Id(Long id);
    @Query("SELECT i FROM CommandeEntity i WHERE i.livreurId = :id")
    public List<CommandeEntity>findAllByLivreurId(Long id);



    @Query("SELECT i FROM CommandeEntity i WHERE i.iduser = :iduser AND i.archived = false")
    List<CommandeEntity> findAllByUserIdAndNotArchived(Long iduser);
    @Query("SELECT i FROM CommandeEntity i WHERE i.iduser = :iduser AND i.archived = true")
    List<CommandeEntity> findAllByUserIdAndArchived(Long iduser);



    @Query("SELECT c FROM CommandeEntity c WHERE c.livreurId = :livreurId AND c.archived = false")
    List<CommandeEntity> findAllByLivreurIdAndNotArchived(Long livreurId);

    @Query("SELECT c FROM CommandeEntity c WHERE c.livreurId = :livreurId AND c.archived = true")
    List<CommandeEntity> findAllByLivreurIdAndArchived(Long livreurId);

    List<CommandeEntity> findByLivreurId(Long livreurId);
    List<CommandeEntity> findByIdpartenaire(Long idpartenaire); // Corrected method name

}
