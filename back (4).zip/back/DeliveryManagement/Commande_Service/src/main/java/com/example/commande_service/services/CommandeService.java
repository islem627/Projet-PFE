package com.example.commande_service.services;
import com.example.commande_service.DTO.OrderUpdate;
import com.example.commande_service.entities.CommandeEntity;
import com.example.commande_service.repositories.CommandeRepo;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.logging.Logger;

@Service
public class CommandeService {
    @Autowired
    CommandeRepo commandeRepo;
    @Autowired
    private SimpMessagingTemplate messagingTemplate;
    private CommandeService commandeService;
    @Value("${invoice.storage.path}")
    private String invoiceStoragePath;

    public CommandeEntity create(CommandeEntity commandeEntity) {
        return commandeRepo.save(commandeEntity);
    }

    public CommandeEntity one_commande(Long id_commande) {
        return commandeRepo.findById(id_commande).orElse(null);
    }

    public List<CommandeEntity> GetAll() {
        return commandeRepo.findAll();
    }

    public void Delete(Long id_commande) {
        commandeRepo.deleteById(id_commande);
    }

    public CommandeEntity update(CommandeEntity commandeEntity) {
        return commandeRepo.save(commandeEntity);
    }


    public List<CommandeEntity> alltasksbyIdproduct(Long id) {
        return commandeRepo.findAllByProject_Id(id);
    }

    public List<CommandeEntity> alltasksbyIduser(Long id) {
        return commandeRepo.findAllByUser_Id(id);
    }

    public List<CommandeEntity> alltasksbyIdLivreur(Long id) {
        return commandeRepo.findAllByLivreurId(id);
    }

    public CommandeEntity findById(Long idcommande) {
        return commandeRepo.findById(idcommande).orElse(null);
    }


    public CommandeEntity updateOrderStatus(Long orderId, String newStatus) {
        CommandeEntity commande = commandeRepo.findById(orderId)
                .orElseThrow(() -> new RuntimeException("Commande non trouvée"));
        commande.setStatut_commande(newStatus); // Supposons que CommandeEntity a un champ "status"
        return update(commande);
    }



    public void archiveCommande(Long id) {
        CommandeEntity commande = commandeRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Commande non trouvée: " + id));
        commande.setArchived(true);
        commandeRepo.save(commande);
    }

    public void unarchiveCommande(Long id) {
        CommandeEntity commande = commandeRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Commande non trouvée: " + id));
        commande.setArchived(false);
        commandeRepo.save(commande);
    }

    public List<CommandeEntity> getActiveCommandes(Long iduser) {
        return commandeRepo.findAllByUserIdAndNotArchived(iduser);
    }

    public List<CommandeEntity> getArchivedCommandes(Long iduser) {
        return commandeRepo.findAllByUserIdAndArchived(iduser);
    }

    public CommandeEntity addEvaluation(Long idCommande, Float noteClient, String commentaireClient, Long userId) {
        CommandeEntity commande = commandeRepo.findById(idCommande)
                .orElseThrow(() -> new RuntimeException("Commande non trouvée: " + idCommande));
        // Vérifier que l'utilisateur est autorisé à évaluer (propriétaire de la commande)
        if (!commande.getIduser().equals(userId)) {
            throw new RuntimeException("Utilisateur non autorisé à évaluer cette commande");
        }
        // Vérifier que la commande est livrée
        if (!"DELIVERED".equalsIgnoreCase(commande.getStatut_commande())) {
            throw new RuntimeException("La commande doit être livrée pour être évaluée");
        }
        // Vérifier que la note est valide
        if (noteClient != null && (noteClient < 1 || noteClient > 5)) {
            throw new RuntimeException("La note doit être entre 1 et 5");
        }
        // Vérifier si une évaluation existe déjà
        if (commande.getNoteClient() != null) {
            throw new RuntimeException("Cette commande a déjà été évaluée");
        }
        commande.setNoteClient(noteClient);
        commande.setCommentaireClient(commentaireClient);
        return commandeRepo.save(commande);
    }


    public List<CommandeEntity> getActiveCommandesByLivreur(Long livreurId) {
        return commandeRepo.findAllByLivreurIdAndNotArchived(livreurId);
    }

    public List<CommandeEntity> getArchivedCommandesByLivreur(Long livreurId) {
        return commandeRepo.findAllByLivreurIdAndArchived(livreurId);
    }




    public CommandeEntity updateD(CommandeEntity commande) {
        System.out.println("Date dans update avant sauvegarde : " + commande.getDate_affection());
        CommandeEntity savedCommande = commandeRepo.save(commande);
        System.out.println("Date dans update après sauvegarde : " + savedCommande.getDate_affection());
        return savedCommande;
    }



    public List<CommandeEntity> getOrdersByPartnerId(Long partnerId) {
        return commandeRepo.findByIdpartenaire(partnerId); // Updated to match repository
    }


    public double calculerFraisLivraison(double poids_grammes, String deliveryOption) {
        double fraisFixe = 5.0;
        double fraisPoids;
        if (poids_grammes < 1000) {
            fraisPoids = 1.0;
        } else if (poids_grammes >= 1000 && poids_grammes <= 3000) {
            fraisPoids = 2.0;
        } else if (poids_grammes > 3000 && poids_grammes <= 5000) {
            fraisPoids = 3.0;
        } else if (poids_grammes > 5000 && poids_grammes <= 10000) {
            fraisPoids = 4.0;
        } else {
            fraisPoids = 30.0;
        }
        double fraisBase = fraisFixe + fraisPoids;
        if (deliveryOption != null) {
            switch (deliveryOption) {
                case "STANDARD":
                    return fraisBase;
                case "EXPRESS":
                    return fraisBase + 5.0;
                case "WEEKEND":
                    return fraisBase + 2.5;
                case "WEEKEND_EXPRESS":
                    return fraisBase + 7.5;
                default:
                    throw new IllegalArgumentException("Option de livraison invalide.");
            }
        }
        return fraisBase;
    }

    // Méthode pour créer une commande
    public CommandeEntity createC(CommandeEntity commande, String deliveryOption) {
        // Validation du poids (en grammes)
        if (commande.getPoids_grammes() <= 0) {
            throw new IllegalArgumentException("Le poids doit être supérieur à 0.");
        }

        // Validation de idpartenaire
        if (commande.getIdpartenaire() == null) {
            throw new IllegalArgumentException("L'ID du partenaire doit être fourni.");
        }

        // Calculer les frais de livraison
        commande.setFraisLivraison(calculerFraisLivraison(commande.getPoids_grammes(), deliveryOption));

        // Définir la date d'ajout au système si non définie
        if (commande.getDate_ajoutsystem() == null) {
            commande.setDate_ajoutsystem(LocalDateTime.now());
        }

        // Sauvegarder la commande
        return commandeRepo.save(commande);
    }

    // Temporary method to handle legacy calls to creerCommande
    @Deprecated
    public CommandeEntity creerCommande(CommandeEntity commande, boolean isExpress, boolean isWeekend) {
        String deliveryOption = isExpress ? (isWeekend ? "WEEKEND_EXPRESS" : "EXPRESS") : (isWeekend ? "WEEKEND" : "STANDARD");
        return createC(commande, deliveryOption);
    }

    public String storeInvoice(Long orderId, MultipartFile invoiceFile) throws IOException {
        // Validate order exists
        Optional<CommandeEntity> optionalCommande = commandeRepo.findById(orderId);
        if (!optionalCommande.isPresent()) {
            throw new IllegalArgumentException("Order with ID " + orderId + " not found");
        }

        // Ensure storage directory exists
        Path storageDir = Paths.get(invoiceStoragePath);
        if (!Files.exists(storageDir)) {
            Files.createDirectories(storageDir);
        }

        // Save file
        String fileName = "invoice_" + orderId + ".pdf";
        Path filePath = storageDir.resolve(fileName);
        Files.write(filePath, invoiceFile.getBytes());

        // Update commande with invoice path
        CommandeEntity commande = optionalCommande.get();
        commande.setInvoicePath(invoiceStoragePath + "/" + fileName); // Fixed line
        commandeRepo.save(commande);

        // Return download URL
        return "http://localhost:8764/Commande/invoice/" + orderId + "/download";
    }
}