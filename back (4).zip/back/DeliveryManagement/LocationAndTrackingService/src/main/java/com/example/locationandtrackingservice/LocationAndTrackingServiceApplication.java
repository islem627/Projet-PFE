package com.example.locationandtrackingservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LocationAndTrackingServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(LocationAndTrackingServiceApplication.class, args);
    }

}
