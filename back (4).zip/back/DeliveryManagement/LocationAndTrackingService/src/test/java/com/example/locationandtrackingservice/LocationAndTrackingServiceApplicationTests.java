package com.example.locationandtrackingservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LocationAndTrackingServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
