package com.example.user_service.services;

import com.example.user_service.DTO.UserDTO;
import com.example.user_service.entities.UserEntity;
import com.example.user_service.repositories.UserRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.Optional;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class UserService {
    private static final Logger log = LoggerFactory.getLogger(UserService.class);
    @Autowired
    UserRepo userRepo;

    public UserEntity create(UserEntity userEntity) {
        return userRepo.save(userEntity);
    }

   public UserEntity update(UserEntity userEntity) {
        return userRepo.save(userEntity);
    }

    public UserEntity oneUser(Long id) {
        return userRepo.findById(id).orElse(null);
    }

    public List<UserEntity> GetAll() {
        return userRepo.findAll();
    }

    public void Delete(Long id) {
        userRepo.deleteById(id);
    }

    public UserEntity getUserById (Long id) {

        return userRepo.findById(id).orElse(null);

    }



    public Optional<UserEntity> findByUsername(String username) {
        return userRepo.findByUsername(username);
    }


//    public void sendPasswordResetToken(String email) {
//        UserEntity user = userRepo.findByEmail(email)
//                .orElseThrow(() -> new RuntimeException("Utilisateur non trouvé"));
//
//        String token = UUID.randomUUID().toString();
//        user.setPasswordResetToken(token);
//        userRepo.save(user);
//
//        String resetLink = "http://localhost:4200/reset-password?token=" + token;
//        mailService.sendSimpleMessage(
//                email,
//                "Réinitialisation du mot de passe",
//                "Cliquez sur le lien suivant pour réinitialiser votre mot de passe :\n" + resetLink
//        );
//    }
//
//    public void resetPassword(String token, String newPassword) {
//        UserEntity user = userRepo.findByPasswordResetToken(token)
//                .orElseThrow(() -> new RuntimeException("Token invalide ou expiré"));
//
//        user.setPassword(passwordEncoder.encode(newPassword));
//        user.setPasswordResetToken(null); // on vide le token après utilisation
//        userRepo.save(user);
//    }



    public UserService(UserRepo userRepo) {
        this.userRepo = userRepo;
    }

    public UserEntity save(UserEntity user) {
        return userRepo.save(user);
    }
    /*

    public UserDTO updateDisponibilite(Long id, Boolean disponible) {
        UserEntity user = userRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Utilisateur non trouvé"));

        if (!"LIVREUR".equals(user.getRole())) {
            throw new RuntimeException("Seuls les livreurs peuvent modifier leur disponibilité");
        }

        user.setDisponible(disponible);
        userRepo.save(user);
        return UserDTO.fromEntity(user); // Utilisation de la méthode statique
    }

    public List<UserDTO> findAvailableLivreurs() {
        return userRepo.findByRoleAndDisponibleTrue("LIVREUR")
                .stream()
                .map(UserDTO::fromEntity) // Utilisation de la méthode statique comme référence
                .collect(Collectors.toList());
    }


     */






    // Méthode pour mettre à jour la disponibilité (accessible à tout utilisateur authentifié)
    public UserDTO updateDisponibilite(Long id, Boolean disponible) {
        log.info("Attempting to update disponibilité for user id: {}", id);
        UserEntity user = userRepo.findById(id)
                .orElseThrow(() -> {
                    log.error("Utilisateur non trouvé pour id: {}", id);
                    return new ResponseStatusException(HttpStatus.NOT_FOUND, "Utilisateur non trouvé");
                });

        user.setDisponible(disponible);
        userRepo.save(user);
        UserDTO userDTO = new UserDTO();
        UserDTO result = userDTO.fromEntity(user);
        log.info("Disponibilité updated for user id: {}, disponible: {}", id, disponible);
        return result;
    }

    // Méthode pour trouver les livreurs disponibles
    public List<UserDTO> findAvailableLivreurs() {
        log.info("Fetching available users");
        List<UserEntity> users = userRepo.findByDisponibleTrue();
        log.info("Found {} users in database", users.size());
        List<UserDTO> userDTOs = users.stream()
                .map(user -> new UserDTO().fromEntity(user))
                .collect(Collectors.toList());
        log.info("Found {} available users", userDTOs.size());
        return userDTOs;
    }

}
