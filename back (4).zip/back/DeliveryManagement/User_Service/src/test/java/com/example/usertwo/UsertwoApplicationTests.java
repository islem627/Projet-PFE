package com.example.usertwo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UsertwoApplicationTests {

    @Test
    void contextLoads() {
    }

}
