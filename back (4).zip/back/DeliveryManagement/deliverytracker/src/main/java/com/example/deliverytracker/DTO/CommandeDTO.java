package com.example.deliverytracker.DTO;

import java.time.LocalDate;

public class CommandeDTO {
    private Long id;
    private double latitude;
    private double longitude;
    private String adresse;
    private String statut;
    private LocalDate dateLivraisonEstimee;

    public CommandeDTO() {
    }

    public CommandeDTO(Long id, double latitude, double longitude, String adresse, String statut, LocalDate dateLivraisonEstimee) {
        this.id = id;
        this.latitude = latitude;
        this.longitude = longitude;
        this.adresse = adresse;
        this.statut = statut;
        this.dateLivraisonEstimee = dateLivraisonEstimee;
    }

    // Getters et setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public double getLatitude() { return latitude; }
    public void setLatitude(double latitude) { this.latitude = latitude; }
    public double getLongitude() { return longitude; }
    public void setLongitude(double longitude) { this.longitude = longitude; }
    public String getAdresse() { return adresse; }
    public void setAdresse(String adresse) { this.adresse = adresse; }
    public String getStatut() { return statut; }
    public void setStatut(String statut) { this.statut = statut; }
    public LocalDate getDateLivraisonEstimee() { return dateLivraisonEstimee; }
    public void setDateLivraisonEstimee(LocalDate dateLivraisonEstimee) { this.dateLivraisonEstimee = dateLivraisonEstimee; }
}