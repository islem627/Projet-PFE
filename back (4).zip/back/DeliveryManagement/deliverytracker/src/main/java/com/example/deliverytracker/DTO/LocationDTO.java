package com.example.deliverytracker.DTO;

import com.example.deliverytracker.entity.LocationEntity;

import java.time.ZoneId;

public class LocationDTO {
    private Long id;
    private Long livreur;
    private double latitude;
    private double longitude;
    private Long timestamp; // Timestamp en millisecondes

    // Getters et setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getLivreur() {
        return livreur;
    }

    public void setLivreur(Long livreur) {
        this.livreur = livreur;
    }

    public double getLatitude() {
        return latitude;
    }

    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }

    public Long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Long timestamp) {
        this.timestamp = timestamp;
    }

    // Méthode pour convertir LocationEntity en LocationDTO
    public LocationDTO fromEntity(LocationEntity entity) {
        this.id = entity.getId();
        this.livreur = entity.getLivreur();
        this.latitude = entity.getLatitude();
        this.longitude = entity.getLongitude();
        // Convertir LocalDateTime en Long (millisecondes)
        this.timestamp = entity.getTimestamp()
                .atZone(ZoneId.of("Africa/Tunis"))
                .toInstant()
                .toEpochMilli();
        return this;
    }

    @Override
    public String toString() {
        return "LocationDTO{" +
                "id=" + id +
                ", livreur=" + livreur +
                ", latitude=" + latitude +
                ", longitude=" + longitude +
                ", timestamp=" + timestamp +
                '}';
    }
}