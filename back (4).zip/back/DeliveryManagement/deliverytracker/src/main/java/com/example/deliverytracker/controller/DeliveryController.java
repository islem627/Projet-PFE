/*package com.example.deliverytracker.controller;

import com.example.deliverytracker.model.Location;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/delivery")
public class DeliveryController {
    private final SimpMessagingTemplate messagingTemplate;
    private static final Map<String, Location> locations = new HashMap<>();

    public DeliveryController(SimpMessagingTemplate messagingTemplate) {
        this.messagingTemplate = messagingTemplate;
    }

    @PostMapping("/location")
    public void updateLocation(@RequestBody Location location) {
        locations.put(location.getLivreurId(), location);
        // Diffuser la position via WebSocket
        messagingTemplate.convertAndSend("/topic/location/" + location.getLivreurId(), location);
    }

    @GetMapping("/location/{deliveryId}")
    public Location getLocation(@PathVariable String deliveryId) {
        return locations.getOrDefault(deliveryId, null);
    }
}
*/

package com.example.deliverytracker.controller;

import com.example.deliverytracker.DTO.LocationDTO;
import com.example.deliverytracker.entity.LocationEntity;
import com.example.deliverytracker.repository.LocationRepository;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.util.*;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/delivery")
public class DeliveryController {
    private final SimpMessagingTemplate messagingTemplate;
    private final LocationRepository locationRepository;

    private boolean isWithinGeofence(double lat, double lng) {
        double minLat = 36.4, maxLat = 36.9; // Approx. autour de Tunis
        double minLng = 10.0, maxLng = 10.8;
        return lat >= minLat && lat <= maxLat && lng >= minLng && lng <= maxLng;
    }

    public DeliveryController(SimpMessagingTemplate messagingTemplate, LocationRepository locationRepository) {
        this.messagingTemplate = messagingTemplate;
        this.locationRepository = locationRepository;
    }

   /* @PostMapping("/location")
    public void updateLocation(@RequestBody LocationDTO location) {
        System.out.println("Received location: " + location);
        if (!isWithinGeofence(location.getLatitude(), location.getLongitude())) {
            throw new IllegalArgumentException("Position hors de la zone autorisée (Tunis)");
        }
        LocationEntity entity = new LocationEntity();
        entity.setLivreur(location.getLivreur());
        entity.setLatitude(location.getLatitude());
        entity.setLongitude(location.getLongitude());
        entity.setTimestamp(LocalDateTime.ofInstant(
                Instant.ofEpochMilli(location.getTimestamp()), ZoneId.of("UTC")));
        locationRepository.save(entity);

        String topic = "/topic/location/" + location.getLivreur();
        System.out.println("Sending to WebSocket topic: " + topic);
        messagingTemplate.convertAndSend(topic, location);
        System.out.println("Message sent to WebSocket");
    }

    */

    @PostMapping("/location")
    public ResponseEntity<Void> receiveLocation(@RequestBody LocationDTO locationDTO) {
        if (!isWithinGeofence(locationDTO.getLatitude(), locationDTO.getLongitude())) {
            return ResponseEntity.badRequest()
                    .body(null); // Ou ajouter un message JSON
        }
        LocationEntity entity = new LocationEntity();
        entity.setLatitude(locationDTO.getLatitude());
        entity.setLongitude(locationDTO.getLongitude());
        entity.setTimestamp(Instant.ofEpochMilli(locationDTO.getTimestamp())
                .atZone(ZoneId.of("Africa/Tunis"))
                .toLocalDateTime());
        entity.setLivreur(locationDTO.getLivreur());
        locationRepository.save(entity);
        messagingTemplate.convertAndSend("/topic/location/" + locationDTO.getLivreur(), locationDTO);
        System.out.println("Received location: " + locationDTO);
        System.out.println("Sending to WebSocket topic: /topic/location/" + locationDTO.getLivreur());
        System.out.println("Message sent to WebSocket");
        return ResponseEntity.ok().build();
    }

    @GetMapping("/location/{livreurId}")
    public LocationDTO getLocation(@PathVariable String livreurId) {
        System.out.println("Fetching location for livreurId: " + livreurId);
        Optional<LocationEntity> entity = locationRepository.findTopByLivreurOrderByTimestampDesc(Long.parseLong(livreurId));
        if (entity.isEmpty()) {
            return null;
        }
        return new LocationDTO().fromEntity(entity.get());
    }

    @GetMapping("/livreurs")
    public List<Map<String, String>> getLivreurs() {
        List<Long> livreurIds = locationRepository.findDistinctLivreurIds();
        if (livreurIds.isEmpty()) {
            System.out.println("⚠️ Aucun livreur trouvé dans la table livraisons.");
        } else {
            livreurIds.forEach(id -> System.out.println("📦 Livreur ID trouvé: " + id));
        }
        return livreurIds.stream()
                .map(id -> Map.of("id", id.toString()))
                .collect(Collectors.toList());
    }

    @PostMapping("/send-notification")
    public void sendNotification(@RequestBody NotificationRequest request) {
        try {
            String fcmUrl = "https://fcm.googleapis.com/fcm/send";
            HttpHeaders headers = new HttpHeaders();
            headers.set("Authorization", "key=VOTRE_CLE_SERVEUR_FCM");
            headers.set("Content-Type", "application/json");
            String payload = "{\"to\":\"" + request.getToken() + "\",\"notification\":{\"title\":\"" + request.getTitle() + "\",\"body\":\"" + request.getBody() + "\"}}";
            HttpEntity<String> entity = new HttpEntity<>(payload, headers);
            RestTemplate restTemplate = new RestTemplate();
            restTemplate.postForObject(fcmUrl, entity, String.class);
            System.out.println("Notification sent to: " + request.getToken());
        } catch (Exception e) {
            System.err.println("Error sending notification: " + e.getMessage());
            throw new RuntimeException("Échec envoi notification", e);
        }
    }
}