package com.example.deliverytracker.controller;

import com.example.deliverytracker.DTO.CommandeDTO;
import com.example.deliverytracker.entity.CommandeEntity;
import com.example.deliverytracker.entity.LocationEntity;
import com.example.deliverytracker.DTO.LocationDTO;
import com.example.deliverytracker.repository.LocationRepository;
import com.example.deliverytracker.services.RouteOptimizationService;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/delivery")
public class RouteController {
    private final RouteOptimizationService optimizationService;
    private final LocationRepository locationRepository;
    private static final String GOOGLE_API_KEY = "AIzaSyB4sJjeHjm-JqjRc6ScYiaGM__GZ3qDp2U"; // Clé API valide

    public RouteController(RouteOptimizationService optimizationService, LocationRepository locationRepository) {
        this.optimizationService = optimizationService;
        this.locationRepository = locationRepository;
    }

    @GetMapping("/route/{deliveryId}")
    public List<CommandeDTO> getOptimizedRoute(@PathVariable String deliveryId) {
        Long livreurId = Long.parseLong(deliveryId);
        Optional<LocationEntity> origin = locationRepository.findTopByLivreurOrderByTimestampDesc(livreurId);
        if (origin.isEmpty()) {
            throw new RuntimeException("Livreur non trouvé");
        }
        List<CommandeEntity> optimized = optimizationService.optimizeRoute(
                livreurId, origin.get().getLatitude(), origin.get().getLongitude());
        return optimized.stream()
                .map(c -> new CommandeDTO(
                        c.getId_commande(), // Corrigé de getId_commande
                        c.getLatitude(),
                        c.getLongitude(),
                        c.getAdresse_livraison(), // Corrigé de getAdresse_livraison
                        c.getStatut_commande(), // Corrigé de getStatut_commande
                        c.getDate_livraison_estimee() // Corrigé de getDate_livraison_estimee
                ))
                .collect(Collectors.toList());
    }
}