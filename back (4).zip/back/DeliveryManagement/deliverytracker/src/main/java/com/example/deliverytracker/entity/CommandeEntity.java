package com.example.deliverytracker.entity;

import com.example.deliverytracker.DTO.ProductDTO;
import com.example.deliverytracker.DTO.UserDTO;
import jakarta.persistence.*;
import org.antlr.v4.runtime.misc.NotNull;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
public class CommandeEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id_commande;
    @NotNull
    private LocalDate dateCommande;
    @NotNull
    private String statut_commande = "PENDING";
    @NotNull
    private String adresse_livraison;
    private double total;
    @NotNull
    private String articel_commande;
    private double remise;
    private double fraisLivraison;
    private LocalDate date_livraison_estimee;
    private String commentaires;
    private boolean ispaied = false;
    private double latitude;
    private double longitude;
    @Column(name = "iduser")
    private Long iduser;
    private Long idproduit;
    @ManyToOne
    @JoinColumn(name = "livreurId", referencedColumnName = "id")
    private UserEntity livreur;
    private String gouvernoratCmd;
    @NotNull
    @Column(name = "date_ajoutsystem", columnDefinition = "DATETIME")
    private LocalDateTime date_ajoutsystem;
    @Column(name = "date_affection", columnDefinition = "DATETIME")
    private LocalDateTime date_affection;
    @Column(name = "date_expidetion", columnDefinition = "DATETIME")
    private LocalDateTime date_expidetion;
    @Column(name = "date_livree", columnDefinition = "DATETIME")
    private LocalDateTime date_livree;
    private String enseigne;
    private String destination_enseigne;
    private double poids_grammes;
    private double hauteur_cm;
    private double largeur_cm;
    private double longueur_cm;
    @Column(nullable = false, columnDefinition = "BOOLEAN DEFAULT FALSE")
    private boolean archived = false;
    @Column(length = 1000)
    private String commentaireClient;
    private Float noteClient;
    @Transient
    private ProductDTO productDTO;
    @Transient
    private UserDTO userDTO;

    // Getters et setters
    public Long getId_commande() { return id_commande; }
    public void setId_commande(Long id_commande) { this.id_commande = id_commande; }
    public LocalDate getDateCommande() { return dateCommande; }
    public void setDateCommande(LocalDate dateCommande) { this.dateCommande = dateCommande; }
    public String getStatut_commande() { return statut_commande; }
    public void setStatut_commande(String statut_commande) { this.statut_commande = statut_commande; }
    public String getAdresse_livraison() { return adresse_livraison; }
    public void setAdresse_livraison(String adresse_livraison) { this.adresse_livraison = adresse_livraison; }
    public double getTotal() { return total; }
    public void setTotal(double total) { this.total = total; }
    public String getArticel_commande() { return articel_commande; }
    public void setArticel_commande(String articel_commande) { this.articel_commande = articel_commande; }
    public double getRemise() { return remise; }
    public void setRemise(double remise) { this.remise = remise; }
    public double getFraisLivraison() { return fraisLivraison; }
    public void setFraisLivraison(double fraisLivraison) { this.fraisLivraison = fraisLivraison; }
    public LocalDate getDate_livraison_estimee() { return date_livraison_estimee; }
    public void setDate_livraison_estimee(LocalDate date_livraison_estimee) { this.date_livraison_estimee = date_livraison_estimee; }
    public String getCommentaires() { return commentaires; }
    public void setCommentaires(String commentaires) { this.commentaires = commentaires; }
    public boolean isIspaied() { return ispaied; }
    public void setIspaied(boolean ispaied) { this.ispaied = ispaied; }
    public double getLatitude() { return latitude; }
    public void setLatitude(double latitude) { this.latitude = latitude; }
    public double getLongitude() { return longitude; }
    public void setLongitude(double longitude) { this.longitude = longitude; }
    public Long getIduser() { return iduser; }
    public void setIduser(Long iduser) { this.iduser = iduser; }
    public Long getIdproduit() { return idproduit; }
    public void setIdproduit(Long idproduit) { this.idproduit = idproduit; }
    public UserEntity getLivreur() { return livreur; }
    public void setLivreur(UserEntity livreur) { this.livreur = livreur; }
    public String getGouvernoratCmd() { return gouvernoratCmd; }
    public void setGouvernoratCmd(String gouvernoratCmd) { this.gouvernoratCmd = gouvernoratCmd; }
    public LocalDateTime getDate_ajoutsystem() { return date_ajoutsystem; }
    public void setDate_ajoutsystem(LocalDateTime date_ajoutsystem) { this.date_ajoutsystem = date_ajoutsystem; }
    public LocalDateTime getDate_affection() { return date_affection; }
    public void setDate_affection(LocalDateTime date_affection) { this.date_affection = date_affection; }
    public LocalDateTime getDate_expidetion() { return date_expidetion; }
    public void setDate_expidetion(LocalDateTime date_expidetion) { this.date_expidetion = date_expidetion; }
    public LocalDateTime getDate_livree() { return date_livree; }
    public void setDate_livree(LocalDateTime date_livree) { this.date_livree = date_livree; }
    public String getEnseigne() { return enseigne; }
    public void setEnseigne(String enseigne) { this.enseigne = enseigne; }
    public String getDestination_enseigne() { return destination_enseigne; }
    public void setDestination_enseigne(String destination_enseigne) { this.destination_enseigne = destination_enseigne; }
    public double getPoids_grammes() { return poids_grammes; }
    public void setPoids_grammes(double poids_grammes) { this.poids_grammes = poids_grammes; }
    public double getHauteur_cm() { return hauteur_cm; }
    public void setHauteur_cm(double hauteur_cm) { this.hauteur_cm = hauteur_cm; }
    public double getLargeur_cm() { return largeur_cm; }
    public void setLargeur_cm(double largeur_cm) { this.largeur_cm = largeur_cm; }
    public double getLongueur_cm() { return longueur_cm; }
    public void setLongueur_cm(double longueur_cm) { this.longueur_cm = longueur_cm; }
    public boolean isArchived() { return archived; }
    public void setArchived(boolean archived) { this.archived = archived; }
    public String getCommentaireClient() { return commentaireClient; }
    public void setCommentaireClient(String commentaireClient) { this.commentaireClient = commentaireClient; }
    public Float getNoteClient() { return noteClient; }
    public void setNoteClient(Float noteClient) { this.noteClient = noteClient; }
    public ProductDTO getProductDTO() { return productDTO; }
    public void setProductDTO(ProductDTO productDTO) { this.productDTO = productDTO; }
    public UserDTO getUserDTO() { return userDTO; }
    public void setUserDTO(UserDTO userDTO) { this.userDTO = userDTO; }
}