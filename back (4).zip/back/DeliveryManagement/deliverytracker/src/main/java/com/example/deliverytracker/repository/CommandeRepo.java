package com.example.deliverytracker.repository;

import com.example.deliverytracker.entity.CommandeEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface CommandeRepo extends JpaRepository<CommandeEntity, Long> {
    List<CommandeEntity> findByLivreurId(Long livreurId);
    List<CommandeEntity> findByIduser(Long iduser);
    List<CommandeEntity> findDistinctByLivreurIdNotNull();

    public interface CommandeRepository extends JpaRepository<CommandeEntity, Long> {
        List<CommandeEntity> findByLivreurId(Long livreurId);
    }

}

