package com.example.deliverytracker.repository;

import com.example.deliverytracker.entity.LocationEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import java.util.List;
import java.util.Optional;

public interface LocationRepository extends JpaRepository<LocationEntity, Long> {
    @Query("SELECT DISTINCT l.livreur FROM LocationEntity l WHERE l.livreur IS NOT NULL")
    List<Long> findDistinctLivreurIds();

    Optional<LocationEntity> findTopByLivreurOrderByTimestampDesc(Long livreur);
}