/*package com.example.deliverytracker.services;

import com.example.deliverytracker.DTO.LocationDTO;
import com.example.deliverytracker.entity.LocationEntity;
import com.example.deliverytracker.repository.LocationRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;



@Service
public class Locationservices {
    private static final Logger log = LoggerFactory.getLogger(Locationservices.class);
    @Autowired
    LocationRepository locationRepository;



    public List<LocationEntity> GetAll() {
        return locationRepository.findAll();
    }


    }


 */



