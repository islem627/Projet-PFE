package com.example.deliverytracker.services;

import com.example.deliverytracker.entity.CommandeEntity;
import com.example.deliverytracker.repository.CommandeRepo;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class RouteOptimizationService {
    private final CommandeRepo commandeRepository;
    private final RestTemplate restTemplate = new RestTemplate();
    private static final String GOOGLE_API_KEY = "AIzaSyB4sJjeHjm-JqjRc6ScYiaGM__GZ3qDp2U"; // Clé API Google Maps

    public RouteOptimizationService(CommandeRepo commandeRepository) {
        this.commandeRepository = commandeRepository;
    }

    public List<CommandeEntity> optimizeRoute(Long livreurId, double currentLat, double currentLng) {
        List<CommandeEntity> commandes = commandeRepository.findByLivreurId(livreurId);
        if (commandes.isEmpty()) {
            return commandes;
        }

        String origins = currentLat + "," + currentLng;
        String destinations = commandes.stream()
                .map(c -> c.getLatitude() + "," + c.getLongitude())
                .collect(Collectors.joining("|"));
        String url = String.format(
                "https://maps.googleapis.com/maps/api/distancematrix/json?origins=%s&destinations=%s&key=%s",
                origins, destinations, GOOGLE_API_KEY
        );

        System.out.println("Distance Matrix URL: " + url);

        // Appeler l'API
        try {
            String response = restTemplate.getForObject(url, String.class);
            System.out.println("Distance Matrix Response: " + response);
            // TODO: Parser la réponse JSON pour trier les commandes
            // Pour l'instant, retourner la liste non triée
            return commandes;
        } catch (Exception e) {
            System.err.println("Erreur appel API Distance Matrix: " + e.getMessage());
            return commandes; // Retourner non trié en cas d'erreur
        }
    }}