/*package com.example.mschatsocket.controller;

import com.example.mschatsocket.dto.ChatMessage;
import com.example.mschatsocket.dto.TypingEvent;
import org.springframework.messaging.handler.annotation.DestinationVariable;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import java.time.LocalDateTime;
import java.util.UUID;

@Controller
@CrossOrigin(origins = "http://localhost:4200")
public class WebSocketController {

    @MessageMapping("/chat/{roomId}")
    @SendTo("/topic/{roomId}")
    public ChatMessage chat(@DestinationVariable String roomId, ChatMessage message) {
        System.out.println("Message reçu pour le salon " + roomId + ": " + message);
        String messageId = UUID.randomUUID().toString();
        return new ChatMessage(messageId, message.getMessage(), message.getUser(), LocalDateTime.now(), false, null);
    }

    @MessageMapping("/seen/{roomId}")
    @SendTo("/topic/{roomId}")
    public ChatMessage markMessageSeen(@DestinationVariable String roomId, ChatMessage message) {
        System.out.println("Notification de vu reçue pour le salon " + roomId + ": " + message);
        ChatMessage updatedMessage = new ChatMessage(
                message.getId(),
                message.getMessage(),
                message.getUser(),
                message.getTimestamp(),
                true,
                LocalDateTime.now()
        );
        System.out.println("Diffusion de la notification de vu sur /topic/" + roomId + ": " + updatedMessage);
        return updatedMessage;
    }

    @MessageMapping("/typing/{roomId}")
    @SendTo("/topic/typing/{roomId}")
    public TypingEvent typing(@DestinationVariable String roomId, TypingEvent event) {
        System.out.println("Événement de saisie reçu pour le salon " + roomId + ": " + event);
        return event;
    }
}*/







/*
package com.example.mschatsocket.controller;

import com.example.mschatsocket.dto.ChatMessage;
import com.example.mschatsocket.dto.TypingEvent;
import org.springframework.messaging.handler.annotation.DestinationVariable;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@Controller
@CrossOrigin(origins = "http://localhost:4200")
public class WebSocketController {

    // In-memory storage for messages
    private final Map<String, List<ChatMessage>> messageHistory = new HashMap<>();

    @MessageMapping("/chat/{roomId}")
    @SendTo("/topic/{roomId}")
    public ChatMessage chat(@DestinationVariable String roomId, ChatMessage message) {
        System.out.println("Message reçu pour le salon " + roomId + ": " + message);
        String messageId = UUID.randomUUID().toString();
        ChatMessage newMessage = new ChatMessage(
                messageId,
                message.getMessage(),
                message.getUser(),
                LocalDateTime.now(),
                false,
                null
        );
        // Store the message in the history
        messageHistory.computeIfAbsent(roomId, k -> new ArrayList<>()).add(newMessage);
        return newMessage;
    }

    @MessageMapping("/seen/{roomId}")
    @SendTo("/topic/{roomId}")
    public ChatMessage markMessageSeen(@DestinationVariable String roomId, ChatMessage message) {
        System.out.println("Notification de vu reçue pour le salon " + roomId + ": " + message);
        ChatMessage updatedMessage = new ChatMessage(
                message.getId(),
                message.getMessage(),
                message.getUser(),
                message.getTimestamp(),
                true,
                LocalDateTime.now()
        );
        // Update the message in the history
        List<ChatMessage> roomMessages = messageHistory.getOrDefault(roomId, new ArrayList<>());
        for (int i = 0; i < roomMessages.size(); i++) {
            if (roomMessages.get(i).getId().equals(message.getId())) {
                roomMessages.set(i, updatedMessage);
                break;
            }
        }
        System.out.println("Diffusion de la notification de vu sur /topic/" + roomId + ": " + updatedMessage);
        return updatedMessage;
    }

    @MessageMapping("/typing/{roomId}")
    @SendTo("/topic/typing/{roomId}")
    public TypingEvent typing(@DestinationVariable String roomId, TypingEvent event) {
        System.out.println("Événement de saisie reçu pour le salon " + roomId + ": " + event);
        return event;
    }

    @MessageMapping("/history/{roomId}")
    @SendTo("/topic/{roomId}")
    public List<ChatMessage> getMessageHistory(@DestinationVariable String roomId) {
        System.out.println("Demande d'historique pour le salon " + roomId);
        return messageHistory.getOrDefault(roomId, new ArrayList<>());
    }
}*/

package com.example.mschatsocket.controller;

import com.example.mschatsocket.dto.ChatMessage;
import com.example.mschatsocket.dto.TypingEvent;
import org.springframework.messaging.handler.annotation.DestinationVariable;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@Controller
@CrossOrigin(origins = "http://localhost:4200")
public class WebSocketController {

    private final Map<String, List<ChatMessage>> messageHistory = new HashMap<>();
    // Track unread counts: Map<roomId, Map<userId, unreadCount>>
    private final Map<String, Map<String, Integer>> unreadCounts = new HashMap<>();
    private final SimpMessagingTemplate messagingTemplate;

    public WebSocketController(SimpMessagingTemplate messagingTemplate) {
        this.messagingTemplate = messagingTemplate;
    }

    @MessageMapping("/chat/{roomId}")
    @SendTo("/topic/{roomId}")
    public ChatMessage chat(@DestinationVariable String roomId, ChatMessage message) {
        System.out.println("Message reçu pour le salon " + roomId + ": " + message);
        String messageId = UUID.randomUUID().toString();
        ChatMessage newMessage = new ChatMessage(
                messageId,
                message.getMessage(),
                message.getUser(),
                LocalDateTime.now(),
                false,
                null
        );
        // Store the message in the history
        messageHistory.computeIfAbsent(roomId, k -> new ArrayList<>()).add(newMessage);

        // Increment unread count for other users in the room
        // For simplicity, assume the room has two users, and the recipient is not the sender
        // In a real app, you’d fetch room participants from a database
        String recipientUserId = getRecipientUserId(roomId, message.getUser());
        if (recipientUserId != null) {
            unreadCounts.computeIfAbsent(roomId, k -> new HashMap<>())
                    .merge(recipientUserId, 1, Integer::sum);
            // Send unread count notification to the recipient
            messagingTemplate.convertAndSendToUser(
                    recipientUserId,
                    "/topic/notifications",
                    unreadCounts.get(roomId).getOrDefault(recipientUserId, 0)
            );
        }

        return newMessage;
    }

    @MessageMapping("/seen/{roomId}")
    @SendTo("/topic/{roomId}")
    public ChatMessage markMessageSeen(@DestinationVariable String roomId, ChatMessage message) {
        System.out.println("Notification de vu reçue pour le salon " + roomId + ": " + message);
        ChatMessage updatedMessage = new ChatMessage(
                message.getId(),
                message.getMessage(),
                message.getUser(),
                message.getTimestamp(),
                true,
                LocalDateTime.now()
        );
        // Update the message in the history
        List<ChatMessage> roomMessages = messageHistory.getOrDefault(roomId, new ArrayList<>());
        for (int i = 0; i < roomMessages.size(); i++) {
            if (roomMessages.get(i).getId().equals(message.getId())) {
                roomMessages.set(i, updatedMessage);
                break;
            }
        }

        // Decrement unread count for the user who marked the message as seen
        String userId = message.getUser(); // The user who sent the message (sender)
        String viewerId = getRecipientUserId(roomId, userId); // The user who viewed it
        if (viewerId != null && unreadCounts.containsKey(roomId)) {
            Map<String, Integer> roomUnreadCounts = unreadCounts.get(roomId);
            if (roomUnreadCounts.containsKey(viewerId)) {
                roomUnreadCounts.put(viewerId, Math.max(0, roomUnreadCounts.get(viewerId) - 1));
                // Send updated unread count to the viewer
                messagingTemplate.convertAndSendToUser(
                        viewerId,
                        "/topic/notifications",
                        roomUnreadCounts.getOrDefault(viewerId, 0)
                );
            }
        }

        System.out.println("Diffusion de la notification de vu sur /topic/" + roomId + ": " + updatedMessage);
        return updatedMessage;
    }

    @MessageMapping("/typing/{roomId}")
    @SendTo("/topic/typing/{roomId}")
    public TypingEvent typing(@DestinationVariable String roomId, TypingEvent event) {
        System.out.println("Événement de saisie reçu pour le salon " + roomId + ": " + event);
        return event;
    }

    @MessageMapping("/history/{roomId}")
    @SendTo("/topic/{roomId}")
    public List<ChatMessage> getMessageHistory(@DestinationVariable String roomId) {
        System.out.println("Demande d'historique pour le salon " + roomId);
        return messageHistory.getOrDefault(roomId, new ArrayList<>());
    }

    // Helper method to get the recipient user ID (simplified)
    private String getRecipientUserId(String roomId, String senderId) {
        // In a real app, fetch room participants from a database
        // For simplicity, assume roomId is shared between two users, e.g., "user1-user2"
        String[] users = roomId.split("-");
        return users[0].equals(senderId) ? users[1] : users[0];
    }
}