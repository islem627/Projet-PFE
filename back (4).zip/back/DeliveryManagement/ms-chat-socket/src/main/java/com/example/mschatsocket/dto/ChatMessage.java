/*package com.example.mschatsocket.dto;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor

public class ChatMessage {
    String message;
    String user;

}
*/


package com.example.mschatsocket.dto;
import lombok.AllArgsConstructor;
import lombok.Data;
import java.time.LocalDateTime;

@Data
@AllArgsConstructor
public class ChatMessage {
    String id; // Ajout du champ id
    String message;
    String user;
    LocalDateTime timestamp;
    boolean seen; // Ajout du statut vu
    LocalDateTime seenTimestamp; // Ajout de l'horodatage du vu
}