// src/main/java/com/example/mschatsocket/dto/TypingEvent.java
package com.example.mschatsocket.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class TypingEvent {
    private String user;
    private boolean isTyping; // Doit être 'isTyping'
}